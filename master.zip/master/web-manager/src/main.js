import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Axios from 'axios';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import echarts from 'echarts'

Vue.prototype.$echarts = echarts

Vue.config.productionTip = false
Vue.use(ElementUI);

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')

// Axios.defaults.baseURL = "http://43.227.199.141:86"
// Axios.defaults.baseURL = "http://localhost:8891"
Axios.defaults.baseURL = "http://juzi.shengtaiyuan.xyz:89"
Axios.defaults.timeout = 10000
Axios.defaults.headers.get['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.put['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.delete['Content-Type'] = 'application/json;charset=UTF-8'
Axios.interceptors.request.use(
    config => {
        // 允许携带cookie
        config.withCredentials = true
        return config
    },
    error => {
        return Promise.error(error)
    }
)

// 响应拦截
// 响应拦截器
Axios.interceptors.response.use(
    response => {
        if (response.status === 200) {
            localStorage.setItem("user", response.headers['login-user'])
            return Promise.resolve(response)
        } else {
            return Promise.reject(response)
        }
    },
    // 服务器状态码不是200的情况
    error => {
        console.log(error)
        if (error.response.status) {
            if (error.response.status == 401) {
                router.replace({
                    path: '/login'
                })
            } else if (error.response.status == 400) {
                if (error.response.data.message == '未抢到') {
                    return Promise.reject(error.response)
                }
                if (error.response.data.message.indexOf("当前时间段不能") !== -1) {
                    return Promise.reject(error.response)
                }
                ElementUI.Message.error(error.response.data.message);
            } else {
                ElementUI.Message.error("网络错误，请稍后再试");
            }
            return Promise.reject(error.response)
        }
    }
)
Vue.prototype.ser = Axios
Vue.prototype.ser.ctx = Axios.defaults.baseURL