import Vue from 'vue'
import VueRouter from 'vue-router'
import home from '../views/admin/home'
import Layout from '../views/admin/layout'

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        component: Layout,
        children: [
            {
                path: '', redirect: 'sys'
                // path: '', redirect: 'home'
            },
            {
                path: 'home',
                name: 'home',
                component: home,
            }
        ]
    },
    {
        path: '/sys',
        component: Layout,
        children: [
            {
                path: '', redirect: 'app-setting'
            },
            {
                path: 'app-setting',
                name: 'app-setting',
                component: () => import('../views/admin/sys/app-setting')
            },
            {
                path: 'bank-setting',
                name: 'bank-setting',
                component: () => import('../views/admin/sys/bank-setting')
            }

        ]
    },
    {
        path: '/assets',
        component: Layout,
        children: [
            {
                path: '', redirect: 'template'
            },
            {
                path: 'template',
                component: () => import('../views/admin/assets/template')
            },
            {
                path: 'goods-info',
                component: () => import('../views/admin/assets/goods-info')
            }
        ]
    },
    {
        path: '/',
        component: Layout,
        children: [
            {
                path: 'users',
                component: () => import('../views/admin/user/list')
            },
            {
                path: 'withdrawal',
                component: () => import('../views/admin/withdrawal/index')
            },
        ]
    },
    {
        path: '/order',
        component: Layout,
        children: [
            {
                path: 'recharge',
                component: () => import('../views/admin/order/recharge-online')
            },
            {
                path: 'assets',
                component: () => import('../views/admin/order/assets')
            },
        ]
    },
    {
        path: '/login',
        component: () => import('../views/login')
    }
]

const router = new VueRouter({
    mode: 'hash',
    base: process.env.BASE_URL,
    routes
})
export default router
