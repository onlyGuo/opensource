<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="less">
  body, html{
    margin: 0;
    padding: 0;
    height: 100%
  }
  #app {
    margin: 0;
    padding: 0;
    height: 100%
  }
</style>
<script>
  import Home from "./views/admin/home";
  import Layout from "./views/admin/layout";
  export default {

  }
</script>