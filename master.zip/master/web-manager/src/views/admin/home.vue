<template>
    <div>
        <el-row>
            <el-col :span="24">
                <box title="近七日资产变动">
                    <echarts-assets-dy height="300"></echarts-assets-dy>
                </box>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="12">
                <box title="全平台资产分布">
                    <echarts-assets height="300"></echarts-assets>
                </box>
            </el-col>
            <el-col :span="12">
                <box title="近七日用户充值金额统计">
                    <echarts-rechange height="300"></echarts-rechange>
                </box>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    import EchartsAssets from "../../components/echarts/echarts-assets";
    import EchartsRechange from "../../components/echarts/echarts-rechange";
    import EchartsAssetsDy from "../../components/echarts/echarts-assets-dy";
    import Box from "../../components/box";
    export default {
        name: "home",
        components: {Box, EchartsAssetsDy, EchartsRechange, EchartsAssets},
        data() {
            return {

            }
        },
        created() {
        },
        mounted() {
        }

    }
</script>

<style scoped>
</style>