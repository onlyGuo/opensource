<template>
    <div v-loading="pageLoading">
        <div class="table-tool" style="height: 50px">
            <div style="width: calc(100% - 100px); float: left">
                <el-form>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="模板类型">
                            <el-select placeholder="请选择" v-model="select.templateId">
                                <el-option label="全部" value="0"></el-option>
                                <el-option
                                        v-for="item in templates"
                                        :key="item.id"
                                        :label="item.templateName"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="资产名称">
                            <el-input v-model="select.keyword" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block;">
                        <el-button @click="reloadTable">搜索</el-button>
                    </div>

                </el-form>
            </div>
            <div style="text-align: right; width: 100px; float: right">
                <el-button type="primary" @click="openEdit(false)">添加资产</el-button>
            </div>
        </div>
        <box title="资产列表">
            <el-table v-loading="tableLoading"
                      :data="tableData"
                      border
                      style="width: 100%">
                <el-table-column prop="templateIcon" label="商品图片" width="120">
                    <template slot-scope="scope">
                        <img :src="scope.row.image" />
                    </template>
                </el-table-column>
                <el-table-column prop="name" label="商品名称">
                </el-table-column>
                <el-table-column prop="shopName" label="商家名称">
                </el-table-column>
                <el-table-column prop="templateName" label="所属模板" width="100">
                </el-table-column>
                <el-table-column prop="price" label="商品价值" width="100"></el-table-column>
                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
                <el-table-column fixed="right" label="操作" width="130">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="openEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="deleteItem(scope.row.id)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="select.totalSize"
                        :page-size="select.pageSize"
                        :current-page="select.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>


        <!-- 添加 -->
        <el-dialog :title="formTitle" :visible.sync="dialogFormVisible">
            <div v-loading="submitLoading">
                <el-form :model="form">
                    <el-form-item label="资产图片" :label-width="formLabelWidth">
                        <div style="border: 1px dashed #d9d9d9; display: inline-block; border-radius: 5px;">
                            <el-upload
                                    v-loading="uploadLoading"
                                    class="avatar-uploader"
                                    :action="(this.ser.ctx + '/api/v1/common/upload')"
                                    with-credentials
                                    :show-file-list="false"
                                    :on-success="handleAvatarSuccess"
                                    :on-error="handleUploaded"
                                    :before-upload="beforeAvatarUpload">
                                <img v-if="form.image" :src="form.image" class="avatar">
                                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            </el-upload>
                        </div>
                    </el-form-item>

                    <el-form-item label="资产模板" :label-width="formLabelWidth">
                        <el-select v-model="form.templateId" placeholder="请选择收款渠道类型">
                            <el-option
                                    v-for="item in templates"
                                    :key="item.id"
                                    :label="item.templateName"
                                    :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="资产名称" :label-width="formLabelWidth">
                        <el-input v-model="form.name" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="商家名称" :label-width="formLabelWidth">
                        <el-input v-model="form.shopName" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="资产价格" :label-width="formLabelWidth">
                        <el-input v-model="form.price" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="submitAssets">确 定</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "goods-info",
        components: {Box},
        data(){
            return {
                pageLoading: false,
                tableLoading: false,
                dialogFormVisible: false,
                formLabelWidth: '80px',
                formTitle: "添加资产",
                uploadLoading: false,
                submitLoading: false,
                templates: [],
                tableData: [],
                select: {
                    page: 1,
                    pageSize: 10,
                    totalSize: 0,
                    templateId: "0",
                    keyword: ''
                },
                form: {}
            }
        },
        methods: {
            loadTemplates(){
                this.pageLoading = true
                this.ser.get("api/v1/admin/assets/template").then(res => {
                    this.templates = res.data
                }).finally(() => {
                    this.pageLoading = false
                })
            },
            reloadTable(){
                this.tableLoading = true
                this.ser.get("api/v1/admin/assets/goods?page=" + this.select.page +
                    "&pageSize=" + this.select.pageSize + "&templateId=" + this.select.templateId +
                    "&keyword=" + this.select.keyword).then(res => {
                    this.tableData = res.data.list
                    this.select.totalSize = res.data.totalSize
                }).finally(() => {
                    this.tableLoading = false
                })
            },
            openEdit(data){
                if (!data){
                    // 添加
                    this.form = {
                        templateId: '',
                        image: '',
                        name: '',
                        shopName: '',
                        price: '',
                    }
                    this.isEdit = false
                }else{
                    this.form = {
                        id: data.id,
                        templateId: data.templateId,
                        image: data.image,
                        name: data.name,
                        shopName: data.shopName,
                        price: data.price,
                        createTime: data.createTime,
                    }
                    this.isEdit = true
                }
                this.dialogFormVisible = true
            },
            deleteItem(id){
                this.$confirm('确定要删除码?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.tableLoading = true
                    this.ser.delete("api/v1/admin/assets/goods/" + id).then(res => {
                        this.$message({
                            type: 'success',
                            message: '删除成功!'
                        });
                        this.reloadTable()
                    }).finally(() => {
                        this.tableLoading = false
                    })
                })
            },
            handleSelectPage(val){
                this.select.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.select.pageSize = val
                this.reloadTable()
            },
            handleAvatarSuccess(res, file) {
                this.form.image = res.responseBody.url;
                this.uploadLoading = false
            },
            handleUploaded(){
                this.uploadLoading = false
                this.$message.error("上传失败")
            },
            beforeAvatarUpload(file) {
                const isLt2M = file.size / 1024 / 1024 < 2;
                const isJPG = (file.type === 'image/jpeg' || file.type === 'image/png')
                if (!isJPG) {
                    this.$message.error('上传图片只能是 JPG 或 PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                this.uploadLoading = true
                return isJPG && isLt2M;
            },
            submitAssets(){
                if (!this.form.templateId){
                    this.$message.error("请选择资一种产类型")
                    return
                }
                this.submitLoading = true
                let req;
                if (this.isEdit){
                    req = this.ser.put("api/v1/admin/assets/goods", this.form)
                }else{
                    req = this.ser.post("api/v1/admin/assets/goods", this.form)
                }
                req.then(res => {
                    this.dialogFormVisible = false
                    this.reloadTable()
                }).finally(() => {
                    this.submitLoading = false
                })
            },
        },
        created() {
            this.loadTemplates()
            this.reloadTable()
        }
    }
</script>

<style scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    .dialog-footer{
        text-align: right;
    }
    .el-table img{
        height: 70px;
        width: 70px;
        border-radius: 10px;
        border: black solid 1px;
    }
</style>