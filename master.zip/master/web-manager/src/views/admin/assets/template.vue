<template>
    <div>
        <div style="height: 50px">
            <div style="text-align: right; width: 100px; float: right">
                <el-button type="primary" @click="openEdit(false)">添加模板</el-button>
            </div>
        </div>
        <box title="模板列表">
            <el-table v-loading="tableLoading"
                      :data="tableData"
                      border
                      style="width: 100%">
                <el-table-column prop="templateIcon" label="模板图标" width="120">
                    <template slot-scope="scope">
                        <img :src="scope.row.templateIcon" />
                    </template>
                </el-table-column>
                <el-table-column prop="templateName" label="模板名称">
                </el-table-column>
                <el-table-column prop="templateMinMoney" label="访问最低限额" width="150"></el-table-column>
                <el-table-column prop="templateProfit" label="返现比例" width="150"></el-table-column>
                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
                <el-table-column prop="status" label="状态" width="100">
                    <template slot-scope="scope">
                        <span v-if="scope.row.status === 0">启用</span>
                        <span v-if="scope.row.status === 1">停用</span>
                    </template>
                </el-table-column>
                <el-table-column fixed="right" label="操作" width="130">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="openEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="upStatus(scope.row)" v-text="scope.row.status === 0 ? '停用' : '启用'"></el-button>
                        <el-button type="text" size="small" @click="deleteItem(scope.row.id)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </box>


        <!-- 添加 -->
        <el-dialog :title="formTitle" :visible.sync="dialogFormVisible">
            <div v-loading="submitLoading">
                <el-form :model="form">
                    <el-form-item label="模板图标" :label-width="formLabelWidth">
                        <div style="border: 1px dashed #d9d9d9; display: inline-block; border-radius: 5px;">
                            <el-upload
                                    v-loading="uploadLoading"
                                    class="avatar-uploader"
                                    :action="(this.ser.ctx + '/api/v1/common/upload')"
                                    with-credentials
                                    :show-file-list="false"
                                    :on-success="handleAvatarSuccess"
                                    :on-error="handleUploaded"
                                    :before-upload="beforeAvatarUpload">
                                <img v-if="form.templateIcon" :src="form.templateIcon" class="avatar">
                                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            </el-upload>
                        </div>
                    </el-form-item>

                    <el-form-item label="模板名称" :label-width="formLabelWidth">
                        <el-input v-model="form.templateName" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="最低限额" :label-width="formLabelWidth">
                        <el-input v-model="form.templateMinMoney" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="返现比例" :label-width="formLabelWidth">
                        <el-slider v-model="form.templateProfit" :step="templateProfitStep"></el-slider>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="submitTemplate">确 定</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "template",
        components: {Box},
        data(){
            return {
                tableLoading: false,
                tableData: [
                ],
                formTitle: '添加模板',
                submitLoading: false,
                formLabelWidth: '80px',
                uploadLoading: false,
                dialogFormVisible: false,
                isEdit: false,
                select: {
                    total: 100,
                    pageSize: 10,
                    page: 1
                },
                templateProfitStep: 0.1,
                form: {
                    templateIcon: '',
                    templateName: '',
                    templateMinMoney: '',
                    templateProfit: 0,
                }
            }
        },
        methods: {
            openEdit(data){
                if (!data){
                    // 添加
                    this.form = {
                        templateIcon: '',
                        templateName: '',
                        templateMinMoney: '',
                        templateProfit: 0,
                    }
                    this.isEdit = false
                }else{
                    this.form = {
                        id: data.id,
                        templateIcon: data.templateIcon,
                        templateName: data.templateName,
                        templateMinMoney: data.templateMinMoney,
                        templateProfit: data.templateProfit,
                        status: data.status,
                        createTime: data.createTime
                    }
                    this.isEdit = true
                }
                this.dialogFormVisible = true
            },
            upStatus(data){
                let form = {
                    id: data.id,
                    templateIcon: data.templateIcon,
                    templateName: data.templateName,
                    templateMinMoney: data.templateMinMoney,
                    templateProfit: data.templateProfit,
                    status: data.status,
                    createTime: data.createTime
                }
                if (form.status === 0){
                    form.status = 1
                }else{
                    form.status = 0
                }
                this.tableLoading = true
                this.ser.put("api/v1/admin/assets/template", form).then(res => {
                    data.status = form.status
                }).then(() => {
                    this.tableLoading = false
                })
            },
            deleteItem(id){
                this.$confirm('删除后该资产下的所有商品将同步删除，确定要继续码?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.tableLoading = true
                    this.ser.delete("api/v1/admin/assets/template/" + id).then(res => {
                        this.$message({
                            type: 'success',
                            message: '删除成功!'
                        });
                        this.reloadTable()
                    }).finally(() => {
                        this.tableLoading = false
                    })
                })
            },
            handleAvatarSuccess(res, file) {
                this.form.templateIcon = res.responseBody.url;
                this.uploadLoading = false
            },
            handleUploaded(){
                this.uploadLoading = false
                this.$message.error("上传失败")
            },
            beforeAvatarUpload(file) {
                const isLt2M = file.size / 1024 / 1024 < 2;
                const isJPG = (file.type === 'image/jpeg' || file.type === 'image/png')
                if (!isJPG) {
                    this.$message.error('上传图片只能是 JPG 或 PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                this.uploadLoading = true
                return isJPG && isLt2M;
            },
            submitTemplate(){
                this.submitLoading = true
                let req;
                if (this.isEdit){
                    req = this.ser.put("api/v1/admin/assets/template", this.form)
                }else{
                    req = this.ser.post("api/v1/admin/assets/template", this.form)
                }
                req.then(res => {
                    this.dialogFormVisible = false
                    this.reloadTable()
                }).finally(() => {
                    this.submitLoading = false
                })
            },
            reloadTable(){
                this.tableLoading = true
                this.ser.get("api/v1/admin/assets/template").then(res => {
                    this.tableData = res.data
                }).finally(() => {
                    this.tableLoading = false
                })
            }
        },
        created() {
            this.reloadTable()
        }
    }
</script>

<style scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    .dialog-footer{
        text-align: right;
    }
    .el-table img{
        height: 70px;
        width: 70px;
        border-radius: 10px;
        border: black solid 1px;
    }
</style>