<template>
    <div>
        <box title="APP设置" v-loading="submitLoading">
            <el-form ref="form" :model="form" label-width="80px">
<!--                <el-form-item label="系统图标">-->
<!--                    <div style="border: 1px dashed #d9d9d9; display: inline-block; border-radius: 5px;">-->
<!--                        <el-upload-->
<!--                                v-loading="uploadLoading"-->
<!--                                class="avatar-uploader"-->
<!--                                :action="(this.ser.ctx + '/api/v1/common/upload')"-->
<!--                                with-credentials-->
<!--                                :show-file-list="false"-->
<!--                                :on-success="handleAvatarSuccess"-->
<!--                                :on-error="handleUploaded"-->
<!--                                :before-upload="beforeAvatarUpload">-->
<!--                            <img v-if="form.icon" :src="form.icon" class="avatar">-->
<!--                            <i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
<!--                        </el-upload>-->
<!--                    </div>-->
<!--                </el-form-item>-->
                <el-form-item label="系统名称">
                    <el-input v-model="form.sysName"></el-input>
                </el-form-item>
                <el-form-item label="起注金额">
                    <el-input v-model="form.minChip"></el-input>
                </el-form-item>
<!--                <el-form-item label="体验金额">-->
<!--                    <el-input v-model="form.testMoney"></el-input>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="抢单时间">-->
<!--                    <el-time-picker-->
<!--                            is-range-->
<!--                            v-model="form.robTimes"-->
<!--                            value-format="HH:mm:ss"-->
<!--                            range-separator="至"-->
<!--                            start-placeholder="开始时间"-->
<!--                            end-placeholder="结束时间"-->
<!--                            placeholder="选择时间范围">-->
<!--                    </el-time-picker>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="每日单数">-->
<!--                    <el-input v-model="form.robCount"></el-input>-->
<!--                </el-form-item>-->
<!--                <el-row>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="金钱名称">-->
<!--                            <el-input v-model="form.moneyName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="佣金名称">-->
<!--                            <el-input v-model="form.newMoneyName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="分红名称">-->
<!--                            <el-input v-model="form.returnMoneyName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                </el-row>-->
<!--                <el-row>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="资产单位">-->
<!--                            <el-input v-model="form.assetsUnit"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="资产名称">-->
<!--                            <el-input v-model="form.assetsName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                </el-row>-->
<!--                <el-row>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="动作名称">-->
<!--                            <el-input v-model="form.robName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                    <el-col :span="8">-->
<!--                        <el-form-item label="冻结名称">-->
<!--                            <el-input v-model="form.frozenName"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </el-col>-->
<!--                </el-row>-->

                <el-row>
                    <el-col :span="8">
                        <el-form-item label="一代分红">
                            <el-input v-model="form.oneReturnReward"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="二代分红">
                            <el-input v-model="form.twoReturnReward"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="三代分红">
                            <el-input v-model="form.threeReturnReward"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="奖1名称">
                            <el-input v-model="form.prize1"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="奖2名称">
                            <el-input v-model="form.prize2"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-form-item label="获奖费率">
                    <el-input v-model="form.rate"></el-input>
                </el-form-item>
<!--                <el-form-item label="抢单开关">-->
<!--                    <el-switch v-model="form.robStatus"></el-switch>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="注册开关">-->
<!--                    <el-switch v-model="form.regStatus"></el-switch>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="抢单几率">-->
<!--                    <el-slider v-model="form.probability"></el-slider>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="聊天公告">-->
<!--                    <el-input type="textarea" v-model="form.roomMessage"></el-input>-->
<!--                </el-form-item>-->
<!--                <el-form-item label="规则介绍">-->
<!--                    <el-input type="textarea" v-model="form.dscp"></el-input>-->
<!--                </el-form-item>-->
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">保存</el-button>
                </el-form-item>
            </el-form>
        </box>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "app-setting",
        components: {Box},
        data() {
            return {
                uploadLoading: false,
                submitLoading: false,
                form: {
                    sysName: '',
                    minChip: '',
                    oneReturnReward: '',
                    twoReturnReward: '',
                    threeReturnReward: '',
                    prize1: '',
                    prize2: '',
                    rate: ''
                }
            }
        },
        methods: {
            onSubmit() {
                this.submitLoading = true

                // 防止提交空的时间
                if (this.form.robTimes.length === 2){
                    if (this.form.robTimes[0]){
                        this.form.startTime = this.form.robTimes[0]
                    }
                    if (this.form.robTimes[1]){
                        this.form.endTime = this.form.robTimes[1]
                    }
                }

                this.ser.put("api/v1/admin/conf", this.form).then(res => {
                    this.$message.success("保存成功")
                }).finally(() => this.submitLoading = false)
            },
            handleAvatarSuccess(res, file) {
                this.form.icon = res.responseBody.url;
                this.uploadLoading = false
            },
            handleUploaded(){
                this.uploadLoading = false
                this.$message.error("上传失败")
            },
            beforeAvatarUpload(file) {
                const isLt2M = file.size / 1024 / 1024 < 2;
                const isJPG = (file.type === 'image/jpeg' || file.type === 'image/png')
                if (!isJPG) {
                    this.$message.error('上传图片只能是 JPG 或 PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                this.uploadLoading = true
                return isJPG && isLt2M;
            },
            getAppSetting(){
                this.submitLoading = true
                this.ser.get("api/v1/admin/conf").then(res => {
                    res.data.robTimes = [res.data.startTime, res.data.endTime]
                    this.form = res.data
                }).finally(() => {
                    this.submitLoading = false
                })
            },
        },
        created() {
            this.getAppSetting()
        }
    }
</script>

<style scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>