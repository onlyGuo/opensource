<template>
    <div>
        <div class="table-tool">
            <div class="left">
                <el-form>
                    <el-form-item label="账户类型">
                        <el-select placeholder="请选择" @change="reloadTable" v-model="select.type">
                            <el-option label="全部" value="all"></el-option>
                            <el-option label="微信" value="wechat"></el-option>
                            <el-option label="支付宝" value="alipay"></el-option>
                            <el-option label="银行卡" value="bank"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </div>
            <div class="right">
                <el-button type="primary" @click="openEdit(false)">添加账户</el-button>
            </div>
        </div>
        <box title="收款账户列表">
            <el-table v-loading="tableLoading"
                    :data="tableData"
                    border
                    style="width: 100%">
                <el-table-column prop="type" label="收款类型" width="120">
                    <template slot-scope="scope">
                        <span v-if="scope.row.type === 'bank'">银行卡</span>
                        <span v-if="scope.row.type === 'wechat'">微信</span>
                        <span v-if="scope.row.type === 'alipay'">支付宝</span>
                    </template>
                </el-table-column>
                <el-table-column prop="accountBank" label="账户开户行">
                    <template slot-scope="scope">
                        <span v-if="scope.row.type === 'wechat'">微信</span>
                        <span v-if="scope.row.type === 'alipay'">支付宝</span>
                        <span v-if="scope.row.type === 'bank'" v-text="scope.row.accountBank">银行卡</span>
                    </template>
                </el-table-column>
                <el-table-column label="收款账户">
                    <template slot-scope="scope">
                        <div style="text-align: center" v-if="scope.row.type === 'wechat' || scope.row.type === 'alipay'">
                            <img :src="scope.row.account" style="height: 80px; width: 80px; border-radius: 5px; box-shadow: black 1px 1px 10px -5px; border: gray solid 1px;" />
                        </div>
                        <span v-if="scope.row.type === 'bank'" v-text="scope.row.account"></span>
                    </template>
                </el-table-column>
                <el-table-column prop="accountName" label="账户名称" width="150"></el-table-column>
                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
                <el-table-column prop="status" label="状态" width="100">
                    <template slot-scope="scope">
                        <span v-if="scope.row.status === 0">启用</span>
                        <span v-if="scope.row.status === 1">停用</span>
                    </template>
                </el-table-column>
                <el-table-column fixed="right" label="操作" width="130">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="openEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="upStatus(scope.row)" v-text="scope.row.status === 0 ? '停用' : '启用'"></el-button>
                        <el-button type="text" size="small" @click="deleteItem(scope.row.id)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="select.total"
                        :page-size="select.pageSize"
                        :current-page="select.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>

        <!-- 添加 -->
        <el-dialog :title="formTitle" :visible.sync="dialogFormVisible">
            <div v-loading="submitLoading">
                <el-form :model="form">
                    <el-form-item label="渠道类型" :label-width="formLabelWidth">
                        <el-select v-model="form.type" placeholder="请选择收款渠道类型">
                            <el-option label="微信" value="wechat"></el-option>
                            <el-option label="支付宝" value="alipay"></el-option>
                            <el-option label="银行卡" value="bank"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="开户行名" :label-width="formLabelWidth">
                        <el-input v-model="form.accountBank" autocomplete="off" :disabled="form.type === 'wechat' || form.type === 'alipay'"></el-input>
                    </el-form-item>
                    <el-form-item label="收款码" v-if="form.type === 'wechat' || form.type === 'alipay'" :label-width="formLabelWidth">
                        <div style="border: 1px dashed #d9d9d9; display: inline-block; border-radius: 5px;">
                            <el-upload
                                    v-loading="uploadLoading"
                                    class="avatar-uploader"
                                    :action="(this.ser.ctx + '/api/v1/common/upload')"
                                    with-credentials
                                    :show-file-list="false"
                                    :on-success="handleAvatarSuccess"
                                    :on-error="handleUploaded"
                                    :before-upload="beforeAvatarUpload">
                                <img v-if="form.account" :src="form.account" class="avatar">
                                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            </el-upload>
                        </div>
                    </el-form-item>
                    <el-form-item label="收款账户" v-if="form.type === 'bank'" :label-width="formLabelWidth">
                        <el-input v-model="form.account" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="单位/姓名" :label-width="formLabelWidth">
                        <el-input v-model="form.accountName" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="submitBank">确 定</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "bank-setting",
        components: {Box},
        data(){
            return {
                tableLoading: false,
                dialogFormVisible: false,
                uploadLoading: false,
                submitLoading: false,
                isEdit: false,
                formTitle: "新增收款渠道",
                select: {
                    type: 'all',
                    total: 0,
                    pageSize: 10,
                    page: 1
                },
                tableData: [],
                form: {
                    type: 'wechat',
                    accountBank: '微信',
                    account: '',
                    accountName: '',
                },
                formLabelWidth: '80px'
            }
        },
        methods: {
            openEdit(data){
                if (data){
                    this.form = {
                        id: data.id,
                        type: data.type,
                        accountBank: data.accountBank,
                        account: data.account,
                        accountName: data.accountName,
                        status: data.status
                    }
                    this.isEdit = true
                    this.formTitle = "编辑收款渠道"
                }else{
                    this.form = {
                        type: 'wechat',
                        accountBank: '微信',
                        account: '',
                        accountName: '',
                    }
                    this.isEdit = false
                    this.formTitle = "新增收款渠道"
                }
                this.dialogFormVisible = true

            },
            deleteItem(id){
                this.$confirm('删除后该收款方式在APP上将不可见, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.tableLoading = true
                    this.ser.delete("api/v1/admin/conf/bank/" + id).then(res => {
                        this.$message({
                            type: 'success',
                            message: '删除成功!'
                        });
                        this.reloadTable()
                    }).finally(() => {
                        this.tableLoading = false
                    })
                })
            },
            upStatus(data){
                this.form = {
                    id: data.id,
                    type: data.type,
                    accountBank: data.accountBank,
                    account: data.account,
                    accountName: data.accountName,
                    status: data.status
                }
                if (this.form.status === 0){
                    this.form.status = 1
                }else{
                    this.form.status = 0
                }
                this.tableLoading = true
                this.ser.put("api/v1/admin/conf/bank", this.form).then(res => {
                    data.status = this.form.status
                }).then(() => {
                    this.tableLoading = false
                })
            },
            submitBank(){
                this.submitLoading = true
                if (this.isEdit){
                    this.ser.put("api/v1/admin/conf/bank", this.form).then(res => {
                        this.submitLoading = false
                        this.dialogFormVisible = false
                        this.isEdit = false
                        this.form = {
                            type: 'wechat',
                            accountBank: '微信',
                            account: '',
                            accountName: '',
                        }
                        this.reloadTable()
                    }).finally(() => {
                        this.submitLoading = false
                    })
                }else{
                    this.ser.post("api/v1/admin/conf/bank", this.form).then(res => {
                        this.submitLoading = false
                        this.dialogFormVisible = false
                        this.form = {
                            type: 'wechat',
                            accountBank: '微信',
                            account: '',
                            accountName: '',
                        }
                        this.reloadTable()
                    }).finally(() => {
                        this.submitLoading = false
                    })
                }
            },
            handleSelectPage(val){
                this.select.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.select.pageSize = val
                this.reloadTable()
            },
            reloadTable(){
                this.tableLoading = true
                this.ser.get("api/v1/admin/conf/banks?type=" + this.select.type + "&page=" + this.select.page + "&pageSize=" + this.select.pageSize).then(res => {
                    this.select.total = res.data.totalSize
                    this.tableData = res.data.list
                }).finally(() =>{
                    this.tableLoading = false
                })
            },
            handleAvatarSuccess(res, file) {
                this.form.account = res.responseBody.url;
                this.uploadLoading = false
            },
            handleUploaded(){
                this.uploadLoading = false
                this.$message.error("上传失败")
            },
            beforeAvatarUpload(file) {
                const isLt2M = file.size / 1024 / 1024 < 2;
                const isJPG = (file.type === 'image/jpeg' || file.type === 'image/png')
                if (!isJPG) {
                    this.$message.error('上传图片只能是 JPG 或 PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                this.uploadLoading = true
                return isJPG && isLt2M;
            }
        },
        watch: {
            'form.type': function (val) {
                if (val === 'wechat'){
                    this.form.accountBank = '微信'
                }else if (val === 'alipay'){
                    this.form.accountBank = '支付宝'
                }else{
                    this.form.accountBank = ''
                }
            }
        },
        created() {
            this.reloadTable()
        }
    }
</script>

<style scoped>
    .table-tool{
        padding-bottom: 50px;
    }
    .table-tool .left{
        float: left;
        width: calc(100% - 100px);
    }
    .table-tool .right{
        float: right;
    }
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    .dialog-footer{
        text-align: right;
    }
</style>