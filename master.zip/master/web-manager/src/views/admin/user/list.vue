<template>
    <div>
        <div class="table-tool" style="height: 50px">
            <div style="width: calc(100% - 100px); float: left">
                <el-form>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="用户状态">
                            <el-select placeholder="请选择" v-model="params.status">
                                <el-option label="全部" value="-1"></el-option>
                                <el-option
                                        v-for="item in params.statusList"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="是否实名">
                            <el-select placeholder="请选择" v-model="params.isIdCard">
                                <el-option label="全部" value="-1"></el-option>
                                <el-option
                                        v-for="item in params.idCardOprions"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>

                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="关键字">
                            <el-input v-model="params.keyword" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block;">
                        <el-button @click="reloadTable">搜索</el-button>
                    </div>

                </el-form>
            </div>
        </div>
        <box title="用户列表">
            <el-table v-loading="table.tableLoading"
                      :data="table.userList"
                      border
                      style="width: 100%">
                <el-table-column prop="templateIcon" label="头像" width="75">
                    <template slot-scope="scope">
                        <img :src="scope.row.avatar ? scope.row.avatar : require('../../../assets/head-img.png')" />
                    </template>
                </el-table-column>
                <el-table-column prop="nicker" label="昵称">
                </el-table-column>
                <el-table-column prop="username" label="手机号" width="120">
                </el-table-column>
                <el-table-column prop="username" label="状态" width="60">
                    <template slot-scope="scope">
                        <span v-if="scope.row.status === 0">正常</span>
                        <span v-if="scope.row.status === 1">封号</span>
                    </template>
                </el-table-column>
                <el-table-column prop="money" label="可用余额">
                </el-table-column>
<!--                <el-table-column prop="frozenMoney" label="冻结余额">-->
<!--                </el-table-column>-->
<!--                <el-table-column prop="robCount" label="今日单数">-->
<!--                </el-table-column>-->
<!--                <el-table-column prop="newMoney" label="今日收益">-->
<!--                </el-table-column>-->
                <el-table-column prop="returnMoney" label="今日分红">
                </el-table-column>
                <el-table-column prop="price" label="是否实名" width="80">
                    <template slot-scope="scope">
                        <span v-if="scope.row.idcard">是</span>
                        <span v-if="!scope.row.idcard">否</span>
                    </template>
                </el-table-column>
                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
                <el-table-column fixed="right" label="操作" width="90">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="openEdit(scope.row)">编辑</el-button>
                        <el-button type="text" size="small" @click="deleteItem(scope.row.id)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="params.totalSize"
                        :page-size="params.pageSize"
                        :current-page="params.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>

        <!-- 编辑用户 -->
        <el-dialog title="编辑用户" :visible.sync="edit.open">
            <div v-loading="edit.loading">
                <el-form :model="edit.data">
                    <el-form-item label="头像" :label-width="edit.width">
                        <div style="border: 1px dashed #d9d9d9; display: inline-block; border-radius: 5px;">
                            <el-upload
                                    v-loading="edit.uploadLoading"
                                    class="avatar-uploader"
                                    :action="(this.ser.ctx + '/api/v1/common/upload')"
                                    with-credentials
                                    :show-file-list="false"
                                    :on-success="handleAvatarSuccess"
                                    :on-error="handleUploaded"
                                    :before-upload="beforeAvatarUpload">
                                <img v-if="edit.data.avatar" :src="edit.data.avatar" class="avatar">
                                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                            </el-upload>
                        </div>
                    </el-form-item>

                    <el-form-item label="昵称" :label-width="edit.width">
                        <el-input v-model="edit.data.nicker" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="手机号" :label-width="edit.width">
                        <el-input v-model="edit.data.username" autocomplete="off"></el-input>
                    </el-form-item>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="余额" :label-width="edit.width">
                            <el-input v-model="edit.data.money" autocomplete="off"></el-input>
                        </el-form-item>
                    </div>
<!--                    <div style="width: 50%; display: inline-block">-->
<!--                        <el-form-item label="冻结金" :label-width="edit.width">-->
<!--                            <el-input v-model="edit.data.frozenMoney" autocomplete="off"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </div>-->

<!--                    <div style="width: 50%; display: inline-block">-->
<!--                        <el-form-item label="今日单数" :label-width="edit.width">-->
<!--                            <el-input v-model="edit.data.robCount" autocomplete="off"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </div>-->
<!--                    <div style="width: 50%; display: inline-block">-->
<!--                        <el-form-item label="今日收益" :label-width="edit.width">-->
<!--                            <el-input v-model="edit.data.newMoney" autocomplete="off"></el-input>-->
<!--                        </el-form-item>-->
<!--                    </div>-->
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="今日分红" :label-width="edit.width">
                            <el-input v-model="edit.data.returnMoney" autocomplete="off"></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 30%; display: inline-block">
                        <el-form-item label="状态" :label-width="edit.width">
                            <el-select placeholder="请选择" v-model="edit.data.status">
                                <el-option
                                        v-for="item in params.statusList"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>

                    <div style="width: 30%; display: inline-block">
                        <el-form-item label="角色" :label-width="edit.width">
                            <el-select placeholder="请选择" v-model="edit.data.roleType">
                                <el-option
                                        v-for="item in params.userRoles"
                                        :key="item.key"
                                        :label="item.name"
                                        :value="item.key">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="edit.open = false">取 消</el-button>
                    <el-button type="primary" @click="submitUser">确 定</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "list",
        components: {Box},
        data(){
            return {
                params: {
                    statusList: [
                        {id: 0, name: '正常'},
                        {id: 1, name: '禁封'}
                    ],
                    idCardOprions: [
                        {id: 0, name: '未实名'},
                        {id: 1, name: '已实名'}
                    ],
                    userRoles: [
                        {key: "ADMIN", name: "超管"},
                        {key: "REC", name: "充值客服"},
                        {key: "SER", name: "业务客服"},
                        {key: "MVE", name: "兑换客服"},
                        {key: "USER", name: "普通用户"}
                    ],
                    status: '-1',
                    isIdCard: '-1',
                    keyword: '',
                    page: 1,
                    pageSize: 10,
                    totalSize: 0
                },
                table: {
                    userList: [],
                    tableLoading: false
                },
                edit: {
                    open: false,
                    loading: false,
                    width: '80px',
                    uploadLoading: false,
                    data: {}
                }

            }
        },
        methods: {
            reloadTable(){
                this.table.tableLoading = true
                this.ser.get("api/v1/admin/user?status=" + this.params.status +
                    "&isIdcard=" + this.params.isIdCard + "&keyword=" + this.params.keyword +
                    "&page=" + this.params.page + "&pageSize=" + this.params.pageSize).then(res => {
                    this.table.userList = res.data.list
                    this.params.totalSize = res.data.totalSize
                }).finally(() => {
                    this.table.tableLoading = false
                })
            },
            handleSelectPage(val){
                this.params.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.params.pageSize = val
                this.reloadTable()
            },
            openEdit(user){
                this.edit.data = JSON.parse(JSON.stringify(user))
                this.edit.open = true
            },
            submitUser(){
                this.edit.loading = true
                this.ser.put("api/v1/admin/user", this.edit.data).then(res => {
                    this.$message({
                        message: '修改成功',
                        type: 'success'
                    });
                    this.reloadTable()
                    this.edit.open = false
                }).finally(() => {
                    this.edit.loading = false
                })
            },
            deleteItem(id){
                this.table.tableLoading = true
                this.ser.delete("api/v1/admin/user/" + id).then(res => {
                    this.$message({
                        message: '删除成功',
                        type: 'success'
                    });
                    this.reloadTable()
                }).finally(() => {
                    this.table.tableLoading = false
                })
            },
            handleAvatarSuccess(res, file) {
                this.edit.data.avatar = res.responseBody.url;
                this.edit.uploadLoading = false
            },
            handleUploaded(){
                this.edit.uploadLoading = false
                this.$message.error("上传失败")
            },
            beforeAvatarUpload(file) {
                const isLt2M = file.size / 1024 / 1024 < 2;
                const isJPG = (file.type === 'image/jpeg' || file.type === 'image/png')
                if (!isJPG) {
                    this.$message.error('上传图片只能是 JPG 或 PNG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                let res = isJPG && isLt2M;
                if (res){
                    this.edit.uploadLoading = true
                }
                return res
            },
        },
        created() {
            this.reloadTable()
        }
    }
</script>

<style scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
    .dialog-footer{
        text-align: right;
    }
    .el-table img{
        height: 50px;
        width: 50px;
        border-radius: 50%;
        border: white solid 1px;
        box-shadow: rgba(0,0,0,.2) 1px 1px 5px 0;
    }
</style>