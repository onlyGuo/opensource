<template>
    <div>
        <div class="table-tool" style="height: 50px">
            <div style="width: calc(100% - 100px); float: left">
                <el-form>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="提现状态">
                            <el-select placeholder="请选择" v-model="params.status">
                                <el-option label="全部" value="-1"></el-option>
                                <el-option label="待处理" value="0"></el-option>
                                <el-option label="已通过" value="1"></el-option>
                                <el-option label="已驳回" value="2"></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="用户名">
                            <el-input v-model="params.username" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>

                    <div style="display: inline-block;">
                        <el-button @click="reloadTable">搜索</el-button>
                    </div>
                </el-form>
            </div>
        </div>
        <box title="提现申请">
            <el-table v-loading="table.tableLoading"
                      :data="table.withdrawalList"
                      border
                      style="width: 100%">
                <el-table-column prop="nicker" label="用户昵称">
                </el-table-column>
                <el-table-column prop="username" label="手机号">
                </el-table-column>
                <el-table-column prop="money" label="提现金额">
                </el-table-column>
                <el-table-column prop="createTime" label="提现时间" width="180"></el-table-column>
                <el-table-column prop="username" label="状态" width="80">
                    <template slot-scope="scope">
                        <el-tag v-if="scope.row.status === 0" type="warning">待处理</el-tag>
                        <el-tag v-if="scope.row.status === 1" type="success">已通过</el-tag>
                        <el-tag v-if="scope.row.status === 2" type="danger">已驳回</el-tag>
                    </template>
                </el-table-column>
                <el-table-column fixed="right" label="操作" width="90">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="audit(scope.row.id)" v-if="scope.row.status === 0">处理</el-button>
                        <el-button type="text" size="small" v-if="scope.row.status !== 0">已处理</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="params.totalSize"
                        :page-size="params.pageSize"
                        :current-page="params.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>


        <!-- 处理申请 -->
        <el-dialog title="处理申请" :visible.sync="edit.open">
            <div v-loading="edit.loading">
                <el-form :model="edit.data">
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="昵称" :label-width="edit.width">
                            <el-input v-model="edit.data.user.nicker" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="手机号" :label-width="edit.width">
                            <el-input v-model="edit.data.user.username" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="提现金额" :label-width="edit.width">
                            <el-input v-model="edit.data.money" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="身份证号" :label-width="edit.width">
                            <el-input v-model="edit.data.user.idcard" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="银行类型" :label-width="edit.width">
                            <el-input v-model="edit.data.bank.bankType" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="银行卡号" :label-width="edit.width">
                            <el-input v-model="edit.data.bank.bankAccount" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="持卡名称" :label-width="edit.width">
                            <el-input v-model="edit.data.bank.bankPersionName" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <div style="width: 50%; display: inline-block">
                        <el-form-item label="预留手机" :label-width="edit.width">
                            <el-input v-model="edit.data.bank.bankPhone" autocomplete="off" readonly></el-input>
                        </el-form-item>
                    </div>
                    <el-form-item label="开户行" :label-width="edit.width">
                        <el-input v-model="edit.data.bank.bankOpenName" autocomplete="off" readonly></el-input>
                    </el-form-item>
                    <el-form-item label="身份图片" :label-width="edit.width" class="id-card-imgs">
                        <el-image :src="edit.data.user.idCardImg1"></el-image>
                        <el-image :src="edit.data.user.idCardImg2"></el-image>
                    </el-form-item>
                    <el-form-item label="处理结果" :label-width="edit.width">
                        <template>
                            <el-radio v-model="edit.data.status" label="1" border>通过</el-radio>
                            <el-radio v-model="edit.data.status" label="2" border>驳回</el-radio>
                        </template>
                    </el-form-item>
                    <el-form-item label="驳回原因" :label-width="edit.width" v-if="edit.data.status == 2">
                        <el-input
                                type="textarea"
                                :rows="2"
                                placeholder="请输入驳回原因"
                                v-model="edit.data.statusDscp">
                        </el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="edit.open = false">取 消</el-button>
                    <el-button type="primary" @click="submitAudit">确 定</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "index",
        components: {Box},
        data(){
            return {
                params: {
                    totalSize: 0,
                    pageSize: 10,
                    page: 1,
                    status: '-1',
                    username: ''
                },
                table: {
                    tableLoading: false,
                    withdrawalList: []
                },
                edit: {
                    open: false,
                    loading: false,
                    width: '80px',
                    data: {
                        user: {},
                        bank: {},
                        statusDscp: ''
                    }
                }
            }
        },
        methods: {
            reloadTable(){
                this.table.tableLoading = true
                this.ser.get("api/v1/admin/withdrawal?status=" + this.params.status +
                    "&username=" + this.params.username +
                    "&page=" + this.params.page + "&pageSize=" + this.params.pageSize).then(res => {
                    this.table.withdrawalList = res.data.list
                    this.params.totalSize = res.data.totalSize
                }).finally(() => {
                    this.table.tableLoading = false
                })
            },
            handleSelectPage(val){
                this.params.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.params.pageSize = val
                this.reloadTable()
            },
            audit(id){
                // 处理申请
                this.edit.open = true
                this.edit.loading = true
                // 请求详情
                this.ser.get("api/v1/admin/withdrawal/" + id).then(res => {
                    this.edit.data = res.data
                }).finally(() => {
                    this.edit.loading = false
                })
            },
            submitAudit(){
                if (this.edit.data.status != 1 && this.edit.data.status != 2){
                    this.$message.error("请选择处理结果状态")
                    return
                }
                if (this.edit.data.status == 2 && !this.edit.data.statusDscp){
                    this.$message.error("驳回原因不能为空")
                    return
                }
                this.edit.loading = true
                this.ser.put("api/v1/admin/withdrawal", this.edit.data).then(res => {
                    this.reloadTable()
                    this.edit.open = false
                }).finally(() => {
                    this.edit.loading = false
                })
            }
        },
        created() {
            this.reloadTable()
        },
    }
</script>

<style>
    .id-card-imgs .el-image{
        height: 150px;
        width: 250px;
        margin-right: 10px;
    }
</style>
<style scoped>
    .dialog-footer{
        text-align: right;
    }
</style>