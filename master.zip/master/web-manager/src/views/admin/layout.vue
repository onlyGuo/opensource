<template>
    <el-container>
        <el-header class="header"><h3>后台管理系统</h3></el-header>
        <el-aside>
            <left-nav></left-nav>
        </el-aside>
        <el-main>
            <router-view></router-view>
        </el-main>
    </el-container>
</template>

<script>
    import LeftNav from "../../components/left-nav";
    export default {
        name: "layout",
        components: {LeftNav},
        data() {
            return {

            }
        }
    }
</script>

<style scoped>
    .header{
        color: white;
        box-shadow: rgba(0,0,0,.3) 1px 0 7px 1px;
        background-color: #409eff;
    }
    .el-container{
        height: 100%;
    }
    .el-main{
        padding-left: 320px;
        height: calc(100% - 60px);
    }
</style>