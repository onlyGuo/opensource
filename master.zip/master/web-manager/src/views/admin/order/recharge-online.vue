<template>
    <div>
        <div class="table-tool" style="height: 50px">
            <div style="width: calc(100% - 100px); float: left">
                <el-form>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="充值状态">
                            <el-select placeholder="请选择" v-model="params.status">
                                <el-option label="全部" value="-1"></el-option>
                                <el-option label="未付款" value="0"></el-option>
                                <el-option label="已付款" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="用户名">
                            <el-input v-model="params.username" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>

                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="订单号">
                            <el-input v-model="params.orderNo" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block;">
                        <el-button @click="reloadTable">搜索</el-button>
                    </div>
                </el-form>
            </div>
        </div>

        <!-- 列表 -->
        <box title="充值订单">
            <el-table v-loading="table.tableLoading"
                      :data="table.orderList"
                      border
                      style="width: 100%">
                <el-table-column prop="orderNo" label="编号" width="160">
                </el-table-column>
                <el-table-column prop="nicker" label="用户昵称">
                </el-table-column>
                <el-table-column prop="username" label="手机号">
                </el-table-column>
                <el-table-column prop="money" label="充值金额">
                </el-table-column>
                <el-table-column prop="username" label="状态" width="80">
                    <template slot-scope="scope">
                        <el-tag v-if="scope.row.status === 0" type="warning">未付款</el-tag>
                        <el-tag v-if="scope.row.status === 1" type="success">已付款</el-tag>
                    </template>
                </el-table-column>

                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
                <el-table-column fixed="right" label="操作" width="90">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="deleteItem(scope.row.id)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="params.totalSize"
                        :page-size="params.pageSize"
                        :current-page="params.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>

    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "recharge-online",
        components: {Box},
        data(){
            return {
                params: {
                    totalSize: 0,
                    pageSize: 10,
                    page: 1,
                    status: '-1',
                    username: '',
                    orderNo: ''
                },
                table: {
                    tableLoading: false,
                    orderList: []
                }
            }
        },
        methods: {
            reloadTable(){
                this.table.tableLoading = true
                this.ser.get("api/v1/admin/order/recharge-online?status=" + this.params.status +
                    "&username=" + this.params.username + "&orderNo=" + this.params.orderNo +
                    "&page=" + this.params.page + "&pageSize=" + this.params.pageSize).then(res => {
                    this.table.orderList = res.data.list
                    this.params.totalSize = res.data.totalSize
                }).finally(() => {
                    this.table.tableLoading = false
                })
            },
            handleSelectPage(val){
                this.params.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.params.pageSize = val
                this.reloadTable()
            },
            deleteItem(id){
                this.table.tableLoading = true
                this.ser.delete("api/v1/admin/order/recharge-online/" + id).then(res => {
                    this.$message({
                        message: '删除成功',
                        type: 'success'
                    });
                    this.reloadTable()
                }).catch(() => {
                    this.table.tableLoading = false
                })
            }
        },
        created() {
            this.reloadTable()
        }
    }
</script>

<style scoped>

</style>