<template>
    <div v-loading="pageLoading">
        <div class="table-tool" style="height: 50px">
            <div style="width: calc(100% - 100px); float: left">
                <el-form>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="奖盘状态">
                            <el-select placeholder="请选择" v-model="params.status">
                                <el-option label="全部" value="-1"></el-option>
                                <el-option label="未开盘" value="0"></el-option>
                                <el-option label="已开盘" value="1"></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="用户名">
                            <el-input v-model="params.username" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>

                    <div style="display: inline-block; width: 300px">
                        <el-form-item label="奖盘编号">
                            <el-input v-model="params.orderNo" autocomplete="off" placeholder="请输入查询关键字" style="width: 200px"></el-input>
                        </el-form-item>
                    </div>
                    <div style="display: inline-block;">
                        <el-button @click="reloadTable">搜索</el-button>
                    </div>
                </el-form>
            </div>
        </div>

        <!-- 列表 -->
        <box title="流水订单">
            <el-table v-loading="table.tableLoading"
                      :data="table.orderList"
                      border
                      style="width: 100%">
                <el-table-column prop="orderId" label="奖盘编号" width="160">
                </el-table-column>
                <el-table-column prop="nicker" label="用户昵称">
                </el-table-column>
                <el-table-column prop="username" label="手机号">
                </el-table-column>
                <el-table-column prop="prizeDscp" label="下注类型">
                </el-table-column>
                <el-table-column prop="money" label="下注金额">
                </el-table-column>
                <el-table-column label="开奖状态">
                    <template slot-scope="scope">
                        <el-tag v-if="!scope.row.prizeDscp" type="warning">未开奖</el-tag>
                        <el-tag v-if="scope.row.prizeDscp" type="success">{{scope.row.prizeDscp}}</el-tag>
                    </template>
                </el-table-column>

                <el-table-column prop="createTime" label="创建时间" width="180"></el-table-column>
            </el-table>
            <div style="margin-top: 20px; text-align: center">
                <el-pagination
                        background
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="params.totalSize"
                        :page-size="params.pageSize"
                        :current-page="params.page"
                        @size-change="handleSelectPageSize"
                        @current-change="handleSelectPage">
                </el-pagination>
            </div>
        </box>
    </div>
</template>

<script>
    import Box from "../../../components/box";
    export default {
        name: "assets",
        components: {Box},
        data(){
            return {
                params: {
                    status: '-1',
                    username: '',
                    orderNo: '',
                    totalSize: 0,
                    pageSize: 10,
                    page: 1,
                },
                table: {
                    tableLoading: false,
                    orderList: []
                },
                pageLoading: false
            }
        },
        methods: {
            handleSelectPage(val){
                this.params.page = val
                this.reloadTable()
            },
            handleSelectPageSize(val){
                this.params.pageSize = val
                this.reloadTable()
            },
            reloadTable(){
                this.table.tableLoading = true
                this.ser.get("api/v1/admin/order/order-items?status=" + this.params.status +
                    "&username=" + this.params.username + "&orderNo=" + this.params.orderNo +
                    "&page=" + this.params.page + "&pageSize=" + this.params.pageSize).then(res => {
                    this.table.orderList = res.data.list
                    this.params.totalSize = res.data.totalSize
                }).finally(() => {
                    this.table.tableLoading = false
                })
            }
        },
        created() {
            this.reloadTable()
        }
    }
</script>

<style scoped>

</style>