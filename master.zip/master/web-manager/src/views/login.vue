<template>
    <div class="login-background">
        <div style="padding: 100px">
            <div class="login-box">
                <h1>管理员登录</h1>
                <el-input placeholder="请输入用户名或手机号" v-model="form.username" clearable></el-input>
                <el-input placeholder="请输入登录密码" type="password" v-model="form.password" clearable></el-input>
                <div style="text-align: center" class="submit-btn">
                    <el-button type="primary" style="width: 90%; margin-top: 50px" @click="doLogin">登录</el-button>
                </div>
            </div>
        </div>

    </div>
</template>
<script>
    export default {
        name: "login",
        data(){
            return {
                form: {
                    username: '',
                    password: ''
                }
            }
        },
        methods: {
            doLogin(){
                if (!this.form.username){
                    this.$message.error("请输入登录名")
                    return
                }
                if (!this.form.password){
                    this.$message.error("请输入登录密码")
                    return
                }
                const loading = this.$loading({
                    lock: true,
                    text: 'Loading',
                    spinner: 'el-icon-loading',
                    background: 'rgba(0, 0, 0, 0.7)'
                });
                this.ser.post("api/v1/admin/login", this.form).then(res => {
                    this.setCookie("token", res.data.token)
                    // this.$router.replace({path: '/home'})
                    this.$router.replace({path: '/sys/app-setting'})
                }).finally(() => {
                    loading.close();
                })
            },
            setCookie(name,value){
                var Days = 30;
                var exp = new Date();
                exp.setTime(exp.getTime() + Days*24*60*60*1000);
                document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
            }
        }
    }
</script>

<style scoped>
    .login-background{
        background: url("../assets/login/images/bg.jpg");
        height: 100%;
    }
    .login-box{
        background-color: rgba(255,255,255,.2);
        width: 400px;
        height: 350px;
        border-radius: 10px;
        margin: 100px auto auto auto;
        box-shadow: black 1px 1px 10px -3px;
        padding: 20px;
    }
    h1{
        text-align: center;
        color: white;
    }
    .el-input{
        margin: 10px;
        width: calc(100% - 20px);
    }
</style>