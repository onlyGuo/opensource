<template>
    <div ref="echartsOption" :style="{height: height + 'px'}">统计图1</div>
</template>

<script>
    export default {
        name: "echarts-assets-dy",
        props: {
            height: String
        },
        data() {
            return {
                option: {
                    color: ['#5793f3', '#d14a61', '#675bba'],
                    title: {
                        text: '近七日平台资金变动',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'none',
                        axisPointer: {
                            type: 'cross'
                        }
                    },
                    legend: {
                        data:['充值金额', '提现金额']
                    },
                    xAxis: [
                        {
                            type: 'category',
                            axisTick: {
                                alignWithLabel: true
                            },
                            axisLine: {
                                onZero: false,
                                lineStyle: {
                                    color: '#d14a61'
                                }
                            },
                            axisPointer: {
                                label: {
                                    formatter: function (params) {
                                        return '提现金额  ' + params.value
                                            + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                                    }
                                }
                            },
                            data: ['日期1', '日期2', '日期3', '日期4', '日期5', '日期6', '日期7']
                        },
                        {
                            type: 'category',
                            axisTick: {
                                alignWithLabel: true
                            },
                            axisLine: {
                                onZero: false,
                                lineStyle: {
                                    color: '#5793f3'
                                }
                            },
                            axisPointer: {
                                label: {
                                    formatter: function (params) {
                                        return '充值金额  ' + params.value
                                            + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                                    }
                                }
                            },
                            data: ['日期1', '日期2', '日期3', '日期4', '日期5', '日期6', '日期7']
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value'
                        }
                    ],
                    series: [
                        {
                            name: '用户充值金额',
                            type: 'line',
                            xAxisIndex: 1,
                            smooth: true,
                            data: [2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6]
                        },
                        {
                            name: '用户提现金额',
                            type: 'line',
                            smooth: true,
                            data: [3.9, 5.9, 11.1, 18.7, 48.3, 69.2, 231.6]
                        }
                    ]
                }
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.ser.get("api/v1/admin/home/money-line").then(res => {
                    const myec = this.$echarts.init(this.$refs.echartsOption)
                    this.$data.option.series[0].data = res.data.recharge.moneys
                    this.$data.option.xAxis[0].data = res.data.recharge.days
                    this.$data.option.series[1].data = res.data.withdraw.moneys
                    this.$data.option.xAxis[1].data = res.data.withdraw.days
                    myec.setOption(this.$data.option)
                })
            });
        }
    }
</script>

<style scoped>

</style>