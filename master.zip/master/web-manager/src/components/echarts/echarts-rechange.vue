<template>
    <div ref="rechangeOption" :style="{height: height + 'px'}">统计图1</div>
</template>

<script>
    export default {
        name: "echarts-rechange",
        props: {height: String},
        data(){
            return {
                rechangeOption: {
                    color: ['#3398DB'],
                    title: {
                        text: '近七日用户充值金额统计',
                        subtext: '实时统计柱状图',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                            type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        }
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis: [
                        {
                            type: 'category',
                            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                            axisTick: {
                                alignWithLabel: true
                            }
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value'
                        }
                    ],
                    series: [
                        {
                            name: '充值金额',
                            type: 'bar',
                            barWidth: '60%',
                            data: [10, 52, 200, 334, 390, 330, 220]
                        }
                    ]
                }
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.ser.get("api/v1/admin/home/recharge").then(res => {
                    const myec1 = this.$echarts.init(this.$refs.rechangeOption)
                    this.$data.rechangeOption.xAxis[0].data = res.data.days
                    this.$data.rechangeOption.series[0].data = res.data.moneys
                    myec1.setOption(this.$data.rechangeOption)
                })

            });
        }
    }
</script>

<style scoped>

</style>