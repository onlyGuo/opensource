<template>
    <div ref="assetsOption" :style="{height: height + 'px'}">统计图1</div>
</template>

<script>
    export default {
        name: "echarts-assets",
        props: {height: String},
        data(){
            return {
                assetsOption: {
                    title: {
                        text: '全平台资产分布',
                        subtext: '统计平台总工产生的资产划分',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{a} <br/>{b} : {c} ({d}%)'
                    },
                    series: [
                        {
                            name: '资产类型',
                            type: 'pie',
                            radius: '55%',
                            center: ['50%', '60%'],
                            data: [
                                {value: 335, name: '可用资产'},
                                {value: 310, name: '冻结资产'},
                                {value: 234, name: '活动赠送'},
                                {value: 234, name: '已提现资产'},
                                {value: 234, name: '提现中资产'}
                            ],
                            emphasis: {
                                itemStyle: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            }
                        }
                    ]
                }
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.ser.get("api/v1/admin/home/money-info").then(res => {
                    const myec = this.$echarts.init(this.$refs.assetsOption)
                    this.$data.assetsOption.series[0].data = [
                        {value: res.data.money, name: '可用资金'},
                        {value: res.data.frozenMoney, name: '冻结资金'},
                        {value: res.data.testMoney, name: '体验资金'},
                        {value: res.data.withdrawing, name: '提现中资金'},
                        {value: res.data.withdrawed, name: '已提现资金'},
                    ]
                    myec.setOption(this.$data.assetsOption)
                })

            });
        }
    }
</script>

<style scoped>

</style>