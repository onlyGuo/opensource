<template >
<div class="box-border">
    <div class="box-title">
        <span></span>
        {{title}}
    </div>
    <div class="box-title-line"></div>
    <div>
        <slot></slot>


    </div>
</div>
</template>
<script>
    export default {
        name: "box",
        props: {title: String}
    }
</script>

<style scoped>
    .box-border{
        box-shadow: rgba(0,0,0,.3) 1px 1px 5px 0; margin: 10px; padding: 10px
    }
    .box-title{
        height: 30px; margin-bottom: 10px; line-height: 30px;
    }
    .box-title span{
        border-left: #409eff solid 3px; margin-right: 20px
    }
    .box-title-line{
        border-bottom: rgba(0,0,0,.1) solid 1px; margin-bottom: 10px
    }
</style>