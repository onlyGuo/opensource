<template>
    <el-col>
        <el-menu
                :default-active="this.$route.path"
                class="el-menu-vertical-demo left-nav"
                router
                background-color="#545c64"
                text-color="#fff"
                unique-opened
                active-text-color="#ffd04b">
<!--            <el-menu-item index="/home">-->
<!--                <i class="el-icon-menu"></i>-->
<!--                <span slot="title">仪表盘</span>-->
<!--            </el-menu-item>-->
            <el-submenu index="/sys">
                <template slot="title">
                    <i class="el-icon-setting"></i>
                    <span>系统设置</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="/sys/app-setting">APP设置</el-menu-item>
<!--                    <el-menu-item index="/sys/bank-setting">收款设置</el-menu-item>-->
                </el-menu-item-group>
            </el-submenu>
<!--            <el-submenu index="/assets">-->
<!--                <template slot="title">-->
<!--                    <i class="el-icon-goods"></i>-->
<!--                    <span>资产管理</span>-->
<!--                </template>-->
<!--                <el-menu-item-group>-->
<!--                    <el-menu-item index="/assets/template">资产模板</el-menu-item>-->
<!--                    <el-menu-item index="/assets/goods-info">资产详情</el-menu-item>-->
<!--                </el-menu-item-group>-->
<!--            </el-submenu>-->
            <el-menu-item index="/users">
                <i class="el-icon-user"></i>
                <span slot="title">用户管理</span>
            </el-menu-item>
            <el-submenu index="/order">
                <template slot="title">
                    <i class="el-icon-sort"></i>
                    <span slot="title">交易管理</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="/order/recharge">用户充值管理</el-menu-item>
                    <el-menu-item index="/order/assets">用户流水管理</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
            <el-menu-item index="/withdrawal">
                <i class="el-icon-money"></i>
                <span slot="title">提现管理</span>
            </el-menu-item>
        </el-menu>
    </el-col>
</template>

<script>
    export default {
        name: "left-nav",
        data(){
            return {
            }
        },
        watch: {
        },

        methods: {
        },

        created() {
        }
    }
</script>

<style scoped>
    .left-nav{
        background-color: rgb(84, 92, 100);
        position: absolute;
        bottom: 0;
        top: 60px;
        left: 0;
        width: 300px;
    }
</style>