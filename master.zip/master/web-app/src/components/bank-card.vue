<template>
    <div class="bank-card">
        <div class="edit-btn" @click="editFun">
            <mu-icon value="settings" style="vertical-align: middle;"></mu-icon>
            编辑
        </div>
        <div class="title">
            <mu-icon value="credit_card"></mu-icon>
            <span v-text="bankType" style="font-size: 25px"></span>
        </div>
        <div class="bank-account">
            {{bankAccountFmt}}
        </div>
        <div class="info">
            <div>预留手机: {{bankPhone}}</div>
            <div v-text="bankOpenName"></div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "bank-card",
        props: {
            bankAccount: String,
            bankPhone: String,
            bankOpenName: String,
            bankType: String,
            editFun: Function
        },
        data(){
            return {

            }
        },
        created() {
            this.bankAccountFmt = ''
            let n = 1
            for (let i = 0; i < this.bankAccount.length; i++){
                let c = this.bankAccount.charAt(i)
                this.bankAccountFmt += c
                if (n === 4){
                    this.bankAccountFmt += ' '
                    n = 1
                }else{
                    n ++
                }
            }
        }
    }
</script>

<style scoped>
    .bank-card{
        height: 160px;
        background-color: black;
        margin-top: 10px;
        border-radius: 8px;
    }
    .bank-card .title{
        padding: 10px;
        font-size: 20px;
        line-height: 40px;
    }
    .bank-card .title *{
        font-size: 40px;
        vertical-align: middle;
    }
    .bank-card .bank-account{
        font-size: 20px;
        text-align: center;
        background-color: rgba(255, 255, 255, .25);
        height: 40px;
        line-height: 40px;
    }
    .bank-card .info{
        margin: 10px;
        color: gray;
        font-size: 12px;
        text-align: right;
    }
    .edit-btn{
        border: white solid 1px; position: absolute; right: 15px; margin-top: 10px; padding: 3px;
        border-radius: 5px;
    }
    .edit-btn i{
        font-size: 16px;
    }
</style>