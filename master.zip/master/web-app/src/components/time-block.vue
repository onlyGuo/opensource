<template>
    <mu-paper class="demo-paper" :z-depth="2">
        <div class="time-show">
            <div class="time-page h">{{duMiaoObj.minute}}</div>
            <div class="time-page h">{{duMiaoObj.second}}</div>
        </div>
        <div class="order-count-show">
            已下{{count}}注
            <div>
                当前第{{order.id}}期
            </div>
            <div>
                往期开奖: <span v-text="myConf.lastPrize === 1 ? myConf.prize1 : myConf.prize2">红色</span>
            </div>
        </div>
    </mu-paper>
</template>

<script>
    export default {
        name: "time-block",
        props: {
            conf: null,
            init: Function
        },
        data(){
            return {
                duMiaoObj: {
                    minute: 0,
                    second: 0
                },
                myConf:{},
                order: {},
                wuCha: 0,
                count: 0,
                refCount: 0
            }
        },
        methods: {
            dateFmt(fmt, date){ //author: meizz
                let o = {
                    "M+" : date.getMonth()+1,                 //月份
                    "d+" : date.getDate(),                    //日
                    "h+" : date.getHours(),                   //小时
                    "m+" : date.getMinutes(),                 //分
                    "s+" : date.getSeconds(),                 //秒
                    "q+" : Math.floor((date.getMonth()+3)/3), //季度
                    "S"  : date.getMilliseconds()             //毫秒
                };
                if(/(y+)/.test(fmt))
                    fmt=fmt.replace(RegExp.$1, (date.getFullYear()+"").substr(4 - RegExp.$1.length));
                for(let k in o)
                    if(new RegExp("("+ k +")").test(fmt))
                        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
                return fmt;
            },
            tow(n) {
                return n >= 0 && n < 10 ? '0' + n : '' + n;
            },
            getDate(willTime) {
                let oDate = new Date(new Date().getTime() + this.wuCha);//获取日期对象
                let oldTime = oDate.getTime();//现在距离1970年的毫秒数
                let newDate = new Date(willTime);
                let newTime = newDate.getTime();//2019年距离1970年的毫秒数
                let second = Math.floor((newTime - oldTime) / 1000);//未来时间距离现在的秒数
                let day = Math.floor(second / 86400);//整数部分代表的是天；一天有24*60*60=86400秒 ；
                second = second % 86400;//余数代表剩下的秒数；
                let hour = Math.floor(second / 3600);//整数部分代表小时；
                second %= 3600; //余数代表 剩下的秒数；
                let minute = Math.floor(second / 60);
                second %= 60;
                if (minute < 0){
                    minute = 0;
                    second = 0
                }
                return {
                    day: this.tow(day),
                    hour: this.tow(hour),
                    minute: this.tow(minute),
                    second: this.tow(second)
                };
            },
            getPrizeStatus: function () {
                console.log("我要更新~~~")
                this.ser.get("api/v1/mobile/prize").then(res => {
                    this.count = 0;
                    this.myConf = res.data.sysSettingPO;
                    this.order = res.data
                    let serTime = new Date(Date.parse(res.data.thisTime.replace("-", "/").replace("-", "/"))).getTime();
                    let thisTime = new Date().getTime();
                    this.wuCha = serTime - thisTime;
                    this.duMiaoObj = this.getDate(new Date(Date.parse(this.order.endTime.replace("-", "/").replace("-", "/"))))
                    this.ser.get("api/v1/mobile/prize/count").then(res => {
                        this.count = res.data
                    })
                    if (this.refCount > 0){
                        this.init(res.data.lastPrize.point1, res.data.lastPrize.point2);
                    }
                    this.refCount ++;
                    clearInterval(this.timer);
                    this.timer = setInterval(() => {
                        this.duMiaoObj = this.getDate(new Date(Date.parse(this.order.endTime.replace("-", "/").replace("-", "/"))))
                        if (this.duMiaoObj.minute === '00' && this.duMiaoObj.second === '00') {
                            clearInterval(this.timer);
                            this.getPrizeStatus()
                        }
                    }, 1000)
                    clearInterval(this.timer2);
                    this.timer2 = setInterval(() => {
                        if (this.duMiaoObj.minute !== '00') {
                            this.ser.get("api/v1/mobile/prize/count").then(res => {
                                this.count = res.data
                            })
                        }
                    }, 10000)

                })
            },
            randomNum(minNum,maxNum){
                switch(arguments.length){
                    case 1:
                        return parseInt(Math.random()*minNum+1,10);
                        break;
                    case 2:
                        return parseInt(Math.random()*(maxNum-minNum+1)+minNum,10);
                        break;
                    default:
                        return 0;
                        break;
                }
            }
        },
        created() {
            this.myConf = this.conf;
            this.getPrizeStatus();
        },
        beforeDestroy() {
            clearInterval(this.timer);
            clearInterval(this.timer2);
        }
    }
</script>

<style scoped>
    .demo-paper{
        height: 175px;
        /*background-color: black;*/
        background: url("../assets/login-bg.png");
        background-size: 100%;
        margin-top: 30px;
    }
    .demo-paper .time-page{
        height: 100px;
        width: 120px;
        background-color: white;
        border-radius: 5px;
        display: inline-block;
        margin: auto 20px;
        font-size: 70px;
        box-shadow: inset black 0 0 7px -2px;
    }
    .time-show{
        position: absolute;
        margin-top: -20px;
        width: 100%;
        left: 0;
        text-align: center;
    }
    .order-count-show{
        padding-top: 100px;
        color: white;
        text-align: center;
    }
</style>