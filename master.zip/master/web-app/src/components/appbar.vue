<template>
    <mu-appbar style="text-align: center; position: fixed; top: 0; left: 0; right: 0;"color="primary">
        <mu-button icon slot="left" @click="gotoBack">
            <mu-icon value="keyboard_arrow_left"></mu-icon>
        </mu-button>
        {{title}}
        <mu-button icon slot="right">
        </mu-button>
    </mu-appbar>
</template>

<script>
    export default {
        name: "appbar",
        props: {
            title: String
        },
        methods: {
            gotoBack(){
                this.$router.go(-1)
            }
        }
    }
</script>

<style scoped>

</style>