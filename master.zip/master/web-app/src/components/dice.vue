<template>
    <div style="background-color: black; height: 100%" v-if="showTraning" :class="{'hidden-block': !showTraning}">
        <div style="color: white; text-align: center; font-size: 30px; padding-top: 10px">开奖中</div>
        <div style="padding-top: 90px">
            <div class="" style="display: inline-block; width: 50%; text-align: center">
                <div style="display: inline-block;" >
                    <img :src="require('../assets/dice/' + num1 + '.jpg')" :class="{'trans':traning}">
                </div>
            </div>
            <div class="" style="display: inline-block; width: 50%; text-align: center">
                <div style="display: inline-block;" >
                    <img :src="require('../assets/dice/' + num2 + '.jpg')" :class="{'trans':traning}">
                </div>
            </div>

        </div>

    </div>
</template>

<script>
    export default {
        name: "dice",
        props: {
            traning: Boolean,
            showTraning: Boolean,
            num1: Number,
            num2: Number
        },
        created() {
            // setTimeout(() => {
            //     this.traning = false
            // }, 3000);
        }
    }
</script>

<style scoped>
    .trans{
        display: inline-block;
        animation: rotate 0.2s linear infinite;
    }
    .weizhi{
        animation: mov-weizhi 0.5s linear infinite;
    }
    @keyframes rotate{
        from{transform: rotate(0deg)}
        to{transform: rotate(360deg)}
    }
    /*Safari 和 Chrome:*/
    @-webkit-keyframes rotate
    {
        from{transform: rotate(0deg)}
        to{transform: rotate(360deg)}
    }

    @-webkit-keyframes mov-weizhi
    {
        0%{
            margin-left: 0px;
            margin-top: 0px;
        }
        25%{
            margin-left: 50px;
            margin-top: 50px;
        }
        50%{
            margin-left: 0px;
            margin-top: 100px;
        }
        75%{
            margin-left: -50px;
            margin-top: 50px;
        }
        100%{
            margin-left: 0px;
            margin-top: 0px;
        }
    }
    .hidden-block{
        display: none;
    }
</style>