<template>
    <div>
        <mu-tabs :value.sync="active" color="black" indicator-color="pink" full-width>
            <mu-tab>开奖记录</mu-tab>
            <mu-tab>下注记录</mu-tab>
        </mu-tabs>
        <mu-container>
            <div class="demo-text" ref="container" v-if="active === 0">
                <mu-load-more @refresh="refreshOrderHis" :refreshing="refreshing" :loading="loading" @load="load">
                    <div style="min-height: 50vh">
                        <mu-list textline="two-line">
                            <mu-list-item avatar ripple button v-for="item in orderHis" :key="'order_' + item.id">
                                <mu-list-item-content>
                                    <mu-list-item-title style="color: white">第{{item.id}}期</mu-list-item-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">开奖结果: {{item.prize === 0 ? '未开奖' : (item.prize === 1 ? '大' : '小')}} </mu-list-item-sub-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">
                                        {{item.strartTime}} ~ {{item.endTime}}
                                    </mu-list-item-sub-title>
                                </mu-list-item-content>
                            </mu-list-item>
                        </mu-list>
                    </div>
                </mu-load-more>
            </div>
            <div class="demo-text" v-if="active === 1">
                <mu-load-more @refresh="refreshOrderItemHis" :refreshing="itemRefreshing" :loading="itemLoading" @load="loadItems">
                    <div style="min-height: 50vh">
                        <mu-list textline="two-line">
                            <mu-list-item avatar ripple button v-for="item in orderItemHis" :key="'order_item_' + item.id">
                                <mu-list-item-content>
                                    <mu-list-item-title style="color: white">第{{item.orderId}}期</mu-list-item-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">下注类型: [{{(item.prize === 1 ? '大' : '小')}}] 开奖结果: [{{item.prizeDscp}}] </mu-list-item-sub-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">
                                        下注金额: [{{item.money}}] 下注时间: {{item.createTime}}
                                    </mu-list-item-sub-title>
                                </mu-list-item-content>
                            </mu-list-item>
                        </mu-list>
                    </div>
                </mu-load-more>
            </div>
        </mu-container>

    </div>
</template>

<script>
    export default {
        name: "history",
        data(){
            return {
                active: 0,
                refreshing: false,
                loading: false,
                orderHis: [],
                orderHisPage: 1,
                itemRefreshing: false,
                itemLoading: false,
                orderItemHisPage: 1,
                orderItemHis: []
            }
        },
        methods: {
            refreshOrderHis () {
                this.refreshing = true;
                this.orderHisPage = 1
                this.ser.get("api/v1/mobile/prize/orders?page=" + this.orderHisPage).then(res => {
                    this.orderHis = res.data
                }).finally(() => {
                    this.refreshing = false;
                })
            },
            load () {
                this.loading = true;
                this.ser.get("api/v1/mobile/prize/orders?page=" + (this.orderHisPage + 1)).then(res => {
                    this.orderHis = this.orderHis.concat(res.data)
                    if (res.data.length > 0){
                        this.orderHisPage ++;
                    }
                }).finally(() => {
                    this.loading = false;
                })
            },
            refreshOrderItemHis(){
                this.itemRefreshing = true;
                this.orderItemHisPage = 1
                this.ser.get("api/v1/mobile/prize/orders-item?page=" + this.orderItemHisPage).then(res => {
                    this.orderItemHis = res.data
                }).finally(() => {
                    this.itemRefreshing = false;
                })
            },
            loadItems () {
                this.loading = true;
                this.ser.get("api/v1/mobile/prize/orders-item?page=" + (this.orderItemHisPage + 1)).then(res => {
                    this.orderItemHis = this.orderItemHis.concat(res.data)
                    if (res.data.length > 0){
                        this.orderItemHisPage ++;
                    }
                }).finally(() => {
                    this.itemLoading = false;
                })
            },
        },
        created() {
            this.refreshOrderHis()
            this.refreshOrderItemHis()
        }
    }
</script>

<style scoped>

</style>