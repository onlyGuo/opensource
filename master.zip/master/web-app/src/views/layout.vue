<template>
    <div style="height: 100%" id="layout">
        <mu-appbar style="text-align: center; position: fixed; top: 0; left: 0; right: 0;" :title="conf.sysName" color="primary"></mu-appbar>

<!--        <mu-container style="height: 100%">-->
            <div style="padding-top: 56px; padding-bottom: 56px">
                <router-view :conf="conf"></router-view>
            </div>
<!--        </mu-container>-->
        <mu-bottom-nav mu-bottom-navigation color="secondary" style="bottom: 0;position: fixed;left: 0;right: 0;">
            <mu-bottom-nav-item ripple replace title="项目主页"  icon="home" to="/home"></mu-bottom-nav-item>
            <mu-bottom-nav-item ripple replace title="交流群" icon="chat" to="/chat"></mu-bottom-nav-item>
            <mu-bottom-nav-item ripple replace title="历史开奖" icon="history" to="/history"></mu-bottom-nav-item>
            <mu-bottom-nav-item ripple replace title="设置中心" icon="settings" to="/setting"></mu-bottom-nav-item>
        </mu-bottom-nav>
    </div>
</template>


<script>
    export default {
        name: "layout",
        props: {
            conf: Object
        }
    }
</script>

<style>
    @import 'http://cdn.bootcss.com/material-design-icons/3.0.1/iconfont/material-icons.css';
    .mu-bottom-nav-shift-wrapper{
        background-color: black;
        color: white;
    }
</style>

<style scoped>

</style>