<template>
    <div>
        <appbar title="账户充值"></appbar>
        <mu-container>
            <div style="padding-top: 56px; padding-bottom: 56px" class="bank-card-edit">
                <mu-form :model="form" class="mu-demo-form" :label-position="labelPosition" label-width="100">
                    <mu-form-item prop="select" label="充值金额">
                        <mu-select v-model="form.money">
                            <mu-option v-for="(option, index) in moneyOption" :key="option" :label="option" :value="option"></mu-option>
                        </mu-select>
                    </mu-form-item>
                </mu-form>
                <mu-flex justify-content="center" align-items="center" >
                    <mu-button full-width color="secondary" @click="doRecharge" v-loading="rechargeLoading">充值</mu-button>
                </mu-flex>
            </div>
        </mu-container>
        <div style="display: none">
            <form ref="payForm" :action="payParam.serviceUrl" method="post">
                <input v-for="(value, key) in payParam.params" :key="key" :name="key" :value="value" />
                <button type="submit" ref="payFormSubmit">submit</button>
            </form>
        </div>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "recharge",
        components: {Appbar},
        data(){
            return {
                form: {},
                labelPosition: 'top',
                rechargeLoading: false,
                moneyOption: [
                    "199", '599', '999', '1999', '1599', '2999', '3999', '4999', '6999', '8999', '10999'
                ],
                payParam:{
                    serviceUrl: '',
                    params: {}
                }
            }
        },
        methods: {
            doRecharge(){
                this.rechargeLoading = true
                this.ser.post("api/v1/mobile/recharge/online", this.form).then(res => {
                    this.payParam = res.data.responseBody
                    setTimeout(() => {
                        return this.$refs.payFormSubmit.click()
                    }, 1000)
                    setTimeout(() => {
                        this.rechargeLoading = false
                    }, 3000)
                }).catch(() => {
                    this.rechargeLoading = false
                })
            }
        }
    }
</script>

<style scoped>

</style>
<style>
    .bank-card-edit .mu-select-input{
        color: white!important;
    }
    .bank-card-edit .mu-form{
        color: white!important;
    }
    .bank-card-edit .mu-form-item{
        color: white!important;
    }
    .bank-card-edit .mu-form-item-label{
        color: gray;
    }
    .bank-card-edit .mu-input-line{
        background-color: gray;
    }
    .bank-card-edit .mu-select-action{
        color: white!important;
    }
    .mu-list.mu-list-dense{
        background-color: #424242;
    }
    .mu-text-field-input{
        color: white!important;
    }
</style>