<template>
    <div>
        <mu-container>
            <mu-card>
                <mu-card-header :title="user.nicker" :sub-title="user.phone">
                    <mu-avatar slot="avatar">
                        <img :src="user.avatar ? user.avatar : require('../../assets/logo.png')">
                    </mu-avatar>
                </mu-card-header>
                <mu-card-text>
                    <mu-chip class="demo-chip" color="grey800" style="margin-right: 10px; margin-bottom: 10px">
                        <mu-avatar :size="32" color="secondary">
                            <mu-icon value="attach_money"></mu-icon>
                        </mu-avatar>
                        可用余额 {{user.money}}
                    </mu-chip>
                    <mu-chip class="demo-chip" color="grey800" style="margin-right: 10px; margin-bottom: 10px">
                        <mu-avatar :size="32" color="secondary">
                            <mu-icon value="attach_money"></mu-icon>
                        </mu-avatar>
                        当前积分 {{user.testMoney}}
                    </mu-chip>
                </mu-card-text>
                <mu-card-actions style="text-align: center">
                    <mu-button style="width: 50%" color="black" @click="$router.push({path: '/setting/recharge'})"><mu-icon value="attach_money" left color="secondary"></mu-icon>充值</mu-button>
    <!--                <mu-button style="width: 50%" color="black" @click="$alert('特殊时期, 请在交流群中 @管理员 进行充值')"><mu-icon value="attach_money" left color="secondary"></mu-icon>充值</mu-button>-->
                    <mu-button style="width: 50%" color="black" @click="$router.push({path: '/setting/withdrawal'})" mu-ripple><mu-icon value="event_note" left color="secondary"></mu-icon>提现</mu-button>
                </mu-card-actions>
            </mu-card>

            <div class="setting-menu-list">
                <mu-list>
                    <mu-list-item button mu-ripple @click="$router.push({path: '/setting/info'})">
                        <mu-list-item-action>
                            <mu-icon value="recent_actors"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>个人资料</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>
                    <mu-list-item button mu-ripple @click="$router.push({path: '/setting/idcard'})">
                        <mu-list-item-action>
                            <mu-icon value="verified_user"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>实名认证</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>

                    <mu-list-item button mu-ripple @click="$router.push({path: '/setting/bank'})">
                        <mu-list-item-action>
                            <mu-icon value="credit_card"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>银行卡</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>
                    <mu-list-item button mu-ripple @click="$router.push({path: '/setting/assets'})">
                        <mu-list-item-action>
                            <mu-icon value="receipt"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>收支记录</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>
                    <mu-list-item button mu-ripple @click="$router.push({path: '/setting/password'})">
                        <mu-list-item-action>
                            <mu-icon value="lock"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>修改密码</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>
                    <mu-list-item button mu-ripple @click="share">
                        <mu-list-item-action>
                            <mu-icon value="share"></mu-icon>
                        </mu-list-item-action>
                        <mu-list-item-title>邀请好友</mu-list-item-title>
                        <mu-list-item-action>
                            <mu-icon value="chevron_right"></mu-icon>
                        </mu-list-item-action>
                    </mu-list-item>
                </mu-list>
            </div>
            <div class="img-share" v-if="showShare" @click="showShare = false">
                <img :src="this.ser.ctx + '/api/v1/common/inv/' + this.user.id">
            </div>
            <mu-flex justify-content="center" align-items="center">
                <mu-button full-width color="secondary" mu-ripple @click="logout">退出登录</mu-button>
            </mu-flex>
        </mu-container>
    </div>
</template>

<script>
    export default {
        name: "index",
        data(){
            return {
                user: {},
                showShare: false
            }
        },
        created() {
            this.ser.get("api/v1/mobile/user/info").then(res => {
                this.user = res.data
            })
        },
        methods: {
            logout(){
                this.ser.post("api/v1/mobile/user/logout").then(res => {
                    this.$router.replace({path: '/login'})
                })
            },
            share(){
                this.showShare = true
            }
        }
    }
</script>

<style scoped>
    .mu-card{
        background-color: black;
    }
    .mu-card-header-title .mu-card-title{
        color: white;
    }
    .mu-card-header-title .mu-card-sub-title{
        color: white;
    }
    .setting-menu-list .mu-list{
        color: white;
    }
    .img-share{
        position: fixed;
        left: 0;
        right: 0;
        top: 56px;
        bottom: 56px;
        z-index: 1;
        background-color: black;
        text-align: center;
    }

</style>
<style>
    .mu-item{
        color: white!important;
    }
    .setting-menu-list .mu-item-action{
        color: #ff4081;
    }
</style>