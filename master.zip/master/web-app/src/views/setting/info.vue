<template>
    <div>
        <appbar title="个人资料"></appbar>
        <div style="padding-top: 56px; padding-bottom: 56px" v-loading="uploadLoading">
            <div class="edit-label" @click="updateImage">
                <div class="title" style="">用户头像</div>
                <div class="content">
                    <div style="float: right;">
                        <img :src="userInfo.avatar ? userInfo.avatar : require('../../assets/logo.png')" class="head-img"/>
                        <mu-icon value="keyboard_arrow_right" color="secondary"></mu-icon>
                    </div>
                </div>
            </div>
            <div class="edit-label text">
                <div class="title" style="">用户昵称</div>
                <div class="content">
                    <input type="text" placeholder="请输入用户昵称" v-model="userInfo.nicker"></input>
                </div>
            </div>
            <div class="edit-label text">
                <div class="title" style="">Q Q 账号</div>
                <div class="content">
                    <input type="text" placeholder="请输入QQ账号" v-model="userInfo.qq"></input>
                </div>
            </div>
            <div class="edit-label text">
                <div class="title" style="">Telegram</div>
                <div class="content">
                    <input type="text" placeholder="请输入飞机(Telegram)号" v-model="userInfo.tenegram"></input>
                </div>
            </div>
        </div>
        <mu-container class="button-wrapper">
            <mu-flex justify-content="center" align-items="center">
                <mu-button full-width color="secondary" @click="saveInfo">保存</mu-button>
            </mu-flex>
        </mu-container>
        <div style="display: none">
            <input type="file" ref="imageInput" accept="image/*" @change="doUpload"></input>
        </div>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "info",
        components: {Appbar},
        data(){
            return {
                userInfo: {},
                uploadLoading: false,
            }
        },
        methods: {
            updateImage(){
                return this.$refs.imageInput.click()
            },
            doUpload(){
                let file = this.$refs.imageInput.files[0];
                console.log(file)
                this.$refs.imageInput.value = ''
                this.uploadLoading = true
                let formData = new FormData();
                formData.append("file", file)
                let options = {  // 设置axios的参数
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
                this.$data.loadingShow = true
                this.ser.post("api/v1/common/upload", formData, options).then(res => {
                    this.ser.put("api/v1/mobile/user/avatar", {
                        avatar: res.data.responseBody.url
                    }).then(res1 => {
                        this.userInfo.avatar = res.data.responseBody.url
                    }).finally(() => {
                        this.uploadLoading = false
                    })
                }).catch(() => {
                    this.uploadLoading = false
                })
            },
            saveInfo(){
                this.ser.put("api/v1/mobile/user/nicker", this.userInfo).then(res => {
                    this.$toast.success("修改成功");
                    setTimeout(() => {
                        this.$router.go(-1);
                    }, 1000)
                }).catch(() => {
                    this.uploadLoading = false
                })
            },
        },
        created() {
            this.uploadLoading = true
            this.ser.get("api/v1/mobile/user/info").then(res => {
                this.userInfo = res.data
                if (this.userInfo.nicker === '未设置昵称'){
                    this.userInfo.nicker = '';
                }
            }).finally(() => {
                this.uploadLoading = false
            })
        }
    }
</script>

<style scoped>
    .head-img{
        height: 45px;
        width: 45px;
        background-color: white;
        border-radius: 50%;
        margin-top: -5px;
    }
    .edit-label{
        height: 60px;
        border-bottom: gray solid 1px;
        padding: 0 10px;
    }

    .edit-label .title{
        color: gray; display: inline-block;
        height: 60px;
        width: 70px;
    }
    .edit-label.text{
        height: 40px;
    }
    .edit-label.text .content{
        height: 40px;
    }
    .edit-label.text .title{
        height: 40px;
    }
    .edit-label.text * {
        line-height: 40px;
    }
    .edit-label.text input{
        height: 40px;
        outline: none;
        background-color: transparent!important;
        border: none;
        color: white;
        width: calc(100% - 25px);
    }
    .edit-label .content{
        width: calc(100% - 70px);
        height: 60px;
        display: inline-block;
    }
    .edit-label * {
        line-height: 60px;
        vertical-align: middle;
    }

</style>
<style>
    .mu-form-item{
        color: gray;
    }
    .mu-input-line{
        background-color: gray;
    }
    .mu-text-field-input{
        color: white;
    }
</style>