<template>
    <div>
        <appbar title="绑定银行卡"></appbar>
        <mu-container>
            <div style="padding-top: 56px; padding-bottom: 56px" class="bank-card-edit">
                <bank-card v-if="showCard" :editFun="editFun" :bank-account="form.bankAccount" :bank-type="form.bankType" :bank-phone="form.bankPhone" :bank-open-name="form.bankOpenName"></bank-card>
                <mu-form :model="form" class="mu-demo-form" :label-position="labelPosition" label-width="100" v-if="!showCard">
                    <mu-form-item prop="select" label="银行类型">
                        <mu-select v-model="form.bankType">
                            <mu-option v-for="(option, index) in options" :key="option" :label="option" :value="option"></mu-option>
                        </mu-select>
                    </mu-form-item>
                    <mu-form-item prop="input" label="银行卡号">
                        <mu-text-field v-model="form.bankAccount"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item prop="input" label="持卡人姓名">
                        <mu-text-field v-model="form.bankPersionName"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item prop="input" label="预留手机号">
                        <mu-text-field v-model="form.bankPhone"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item prop="input" label="开户行名称">
                        <mu-text-field v-model="form.bankOpenName"></mu-text-field>
                    </mu-form-item>
                </mu-form>
            </div>
            <mu-flex justify-content="center" align-items="center" v-if="!showCard">
                <mu-button full-width color="secondary" @click="saveBank" v-loading="saveLoading">保存</mu-button>
            </mu-flex>
        </mu-container>


    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    import BankCard from "../../components/bank-card";
    export default {
        name: "bank",
        components: {BankCard, Appbar},
        data(){
            return {
                showCard: false,
                options: [
                    '人民银行', '建设银行', '农业银行', '招商银行',
                    '工商银行', '交通银行', '邮储银行', '中信银行',
                    '兴业银行', '民生银行', '浦发银行', '广大银行',
                    '广发银行', '华夏银行', '平安银行', '浙商银行',
                    '渤海银行', '恒丰银行',
                ],
                form: {
                    bankType: '',
                    bankAccount: '',
                    bankPersionName: '',
                    bankPhone: '',
                    bankOpenName: ''
                },
                labelPosition: 'top',
                saveLoading: false
            }
        },
        methods: {
            saveBank(){
                this.saveLoading = true
                this.ser.put("api/v1/mobile/user/bank", this.form).then(res => {
                    this.showCard = true
                }).finally(() => {
                    this.saveLoading = false
                })
            },
            editFun(){
                this.showCard = false
            }
        },
        created() {
            this.ser.get("api/v1/mobile/user/bank").then(res => {
                if (!res.data || !res.data.bankAccount){
                    this.showCard = false
                }else{
                    this.form = res.data
                    this.showCard = true}
            })
        }
    }
</script>

<style scoped>


</style>
<style>
    .bank-card-edit .mu-select-input{
        color: white!important;
    }
    .bank-card-edit .mu-form{
        color: white!important;
    }
    .bank-card-edit .mu-form-item{
        color: white!important;
    }
    .bank-card-edit .mu-form-item-label{
        color: gray;
    }
    .bank-card-edit .mu-input-line{
        background-color: gray;
    }
    .bank-card-edit .mu-select-action{
        color: white!important;
    }
    .mu-list.mu-list-dense{
        background-color: #424242;
    }
    .mu-text-field-input{
        color: white!important;
    }
</style>