<template>
    <div v-loading="pageLoading">
        <appbar  title="个人资料"></appbar>
        <div style="padding-top: 56px; padding-bottom: 56px">
            <div class="edit-label text">
                <div class="title" style="">真实姓名</div>
                <div class="content">
                    <input type="text" placeholder="请输入真实姓名" v-model="form.name"></input>
                </div>
            </div>
            <div class="edit-label text">
                <div class="title" style="">身份证号</div>
                <div class="content">
                    <input type="text" placeholder="请输入身份证号码" v-model="form.idcard"></input>
                </div>
            </div>
            <div style="padding: 10px">
                <div style="width: 50%; display: inline-block">
                    <div style="padding: 5px">
                        <div class="id-card-box" v-loading="imgCard1Loading">
                            <div class="id-card-border">
                                <div class="height"></div>
                                <div class="width"></div>
                                <img :src="form.idCardImg1 ? form.idCardImg1 : require('../../assets/id-card-1.png')" >
                                <div class="upload-btn" @click="uploadImg(1)">
                                    <i class="fa fa-camera"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="width: 50%; display: inline-block">
                    <div style="padding: 5px">
                        <div class="id-card-box" v-loading="imgCard2Loading">
                            <div class="id-card-border">
                                <div class="height"></div>
                                <div class="width"></div>
                                <img :src="form.idCardImg2 ? form.idCardImg2 : require('../../assets/id-card-2.png')" >
                                <div class="upload-btn" @click="uploadImg(2)">
                                    <i class="fa fa-camera"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <mu-container>
                <mu-flex justify-content="center" align-items="center">
                    <mu-button full-width color="secondary" mu-ripple @click="onSubmit">提交认证</mu-button>
                </mu-flex>
            </mu-container>
        </div>
        <div style="display: none">
            <input type="file" accept="image/*" @change="doUpload()" ref="uploadInput" id="uploadInput">
        </div>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "idcard",
        components: {Appbar},
        data(){
            return {
                form: {
                    name: '',
                    idcard: '',
                    idCardImg1: '',
                    idCardImg2: ''
                },
                selectType: 1,
                pageLoading: false,
                imgCard1Loading: false,
                imgCard2Loading: false
            }
        },
        methods: {
            onSubmit(){
                if (!this.form.idCardImg1 || !this.form.idCardImg2){
                    this.$toast.error("请上传完整的证件照片")
                    return
                }
                this.pageLoading = true
                this.ser.put("api/v1/mobile/user/idcard", this.form).then(res => {
                    this.pageLoading = false
                    this.$toast.success('提交成功')
                    setTimeout(() => {
                        this.$router.go(-1)
                    }, 1000)
                }).catch(err => {
                    this.pageLoading = false
                })
            },
            uploadImg(type){
                this.selectType = type
                return this.$refs.uploadInput.click()
            },
            doUpload(){
                this.pageLoading = true
                let file = this.$refs.uploadInput.files[0];
                this.$refs.uploadInput.value = ''
                let formData = new FormData();
                formData.append("file", file)
                var options = {  // 设置axios的参数
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
                this.ser.post("api/v1/common/upload", formData, options).then(res => {
                    if (this.selectType === 1){
                        this.form.idCardImg1 = res.data.responseBody.url
                    }else{
                        this.form.idCardImg2 = res.data.responseBody.url
                    }
                }).finally(() => {
                    this.pageLoading = false
                })
            },
            getUserInfo(){
                this.pageLoading = true
                this.ser.get("api/v1/mobile/user/info").then(res => {
                    this.form = res.data
                }).finally(() => {
                    this.pageLoading = false
                })
            }
        },
        created() {
            this.getUserInfo()
        }
    }
</script>

<style scoped>
    .edit-label{
        height: 60px;
        border-bottom: gray solid 1px;
        padding: 0 10px;
    }

    .edit-label .title{
        color: gray; display: inline-block;
        height: 60px;
        width: 70px;
    }
    .edit-label.text{
        height: 40px;
    }
    .edit-label.text .content{
        height: 40px;
    }
    .edit-label.text .title{
        height: 40px;
    }
    .edit-label.text * {
        line-height: 40px;
    }
    .edit-label.text input{
        height: 40px;
        outline: none;
        background-color: transparent!important;
        border: none;
        color: white;
        width: calc(100% - 25px);
    }
    .edit-label .content{
        width: calc(100% - 70px);
        height: 60px;
        display: inline-block;
    }
    .edit-label * {
        line-height: 60px;
        vertical-align: middle;
    }

    .id-card-box{
        width: 100%;
        height: 100px;
        display: inline-block;
    }

    .id-card-box .id-card-border{
        border: black solid 3px;
        height: 94px;
    }
    .id-card-border .height{
        height: 100px;
        width: calc(100% - 30px);
        margin: -3px auto auto auto;
        background-color: black;
    }
    .id-card-border .width{
        width: calc(100% + 6px);
        height: 75px;
        margin: -88px auto auto -3px;
        background-color: black;
    }
    .id-card-box img{
        height: 94px;
        display: block;
        margin-top: -84px;
        width: 100%;
    }
    .id-card-box .upload-btn{
        margin-top: -94px;
        background-color: rgba(255,255,255,.3);
        height: 94px;
        font-size: 20px;
        position: absolute;
        width: calc(50% - 26px);
        padding-top: 35px;
    }
</style>