<template>
    <div>
        <appbar title="资金明细"></appbar>
        <div style="padding-top: 56px">
            <mu-list textline="two-line">
                <mu-list-item avatar button ripple v-for="item in assetsList" :key="item.id">
                    <mu-list-item-action>
                        <mu-avatar :color="(item.type === 1 || item.type === 3) ? 'orange' : 'blue'">
                            <mu-icon :value="item.type === 1 ? 'attach_money' : (item.type === 2 ? 'touch_app' : (item.type === 3 ? 'trending_up' : 'launch'))"></mu-icon>
                        </mu-avatar>
                    </mu-list-item-action>
                    <mu-list-item-content>
                        <mu-list-item-title v-text="item.content">账户充值</mu-list-item-title>
                        <mu-list-item-sub-title>{{item.createTime}}</mu-list-item-sub-title>
                    </mu-list-item-content>
                    <mu-list-item-action>
                        <span style="font-size: 20px" :class="[{'orangered': (item.type === 1 || item.type === 3)}, {'gray': ((item.type === 2 || item.type === 4))}]" >
                            <span v-if="item.type === 1 || item.type === 3">+{{item.money}}¥</span>
                            <span v-if="item.type === 2 || item.type === 4">{{item.money}}¥</span>
                        </span>
                    </mu-list-item-action>
                </mu-list-item>
            </mu-list>
        </div>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "assets",
        components: {Appbar},
        data(){
            return {
                assetsList: [
                    // {
                    //     id: 1,
                    //     content: "账户充值",
                    //     type: 1,
                    //     money: 255.55
                    // },
                    // {
                    //     id: 2,
                    //     content: "用户下注",
                    //     type: 2,
                    //     money: -100.00
                    // },
                    // {
                    //     id: 3,
                    //     content: "开奖收益",
                    //     type: 3,
                    //     money: 180.00
                    // },
                    // {
                    //     id: 4,
                    //     content: "账户提现",
                    //     type: 4,
                    //     money: -180.00
                    // }
                ]
            }
        },
        created() {
            this.ser.get("api/v1/mobile/assets").then(res => {
                this.assetsList = res.data
            })
        }
    }
</script>

<style scoped>
    .mu-item-title{
        color: white;
    }
    .mu-item-sub-title{
        color: #b1b1b1;
    }
    .orangered{
        color: orangered;
    }
    .gray{
        color: gray;
    }
</style>