<template>
    <div>
        <appbar title="用户提现"></appbar>
        <mu-container>
            <div style="padding-top: 56px; padding-bottom: 56px">
                <div class="money-block">
                    <div>当前余额</div>
                    <h1 v-text="money"></h1>
                </div>
                <mu-paper class="demo-paper input-box" :z-depth="2">
                    <input type="number" placeholder="请输入提现金额" v-model="form.money"></input>
                </mu-paper>
                <mu-flex justify-content="center" align-items="center" >
                    <mu-button full-width color="secondary" @click="doWithdrawal" v-loading="withdrawalLoading">提现</mu-button>
                </mu-flex>
            </div>
        </mu-container>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "withdrawal",
        components: {Appbar},
        data(){
            return {
                form: {},
                labelPosition: 'top',
                withdrawalLoading: false,
                money: 1000
            }
        },
        methods: {
            doWithdrawal(){
                if (!this.form.money){
                    this.$toast.error("请输入提现金额")
                    return;
                }
                if (this.form.money < 100){
                    this.$toast.error("最低提现金额不能小于100元")
                    return;
                }
                this.withdrawalLoading = true
                this.ser.post("api/v1/mobile/user/withdrawal", this.form).then(res => {
                    this.$alert("提现提交成功, 工作人员会尽快为你办理.")
                    this.money -= this.form.money
                }).finally(() => {
                    this.withdrawalLoading = false
                })
            }

        },
        created() {
            this.ser.get("api/v1/mobile/user/info").then(res => {
                this.money = res.data.money
            })
        }
    }
</script>

<style scoped>
    .money-block{
        background-color: black;
        height: 100px;
        padding: 10px;
    }
    .input-box{
        background-color: black;
        margin-top: 10px;
        height: 50px;
        margin-bottom: 10px;
    }
    .input-box input{
        outline: none;
        border: none;
        width: 100%;
        height: 100%;
        font-size: 20px;
        padding-left: 10px;
        padding-right: 10px;
        background-color: transparent;
        color: white;
        text-align: left;
    }
</style>