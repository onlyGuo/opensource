<template>
    <div>
        <appbar title="修改密码"></appbar>
        <mu-container>
            <div style="padding-top: 56px; padding-bottom: 56px" class="bank-card-edit">
                <mu-form :model="form" class="mu-demo-form" :label-position="labelPosition" label-width="100">
                    <mu-form-item prop="input" label="原始密码">
                        <mu-text-field v-model="form.oldPassword"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item prop="input" label="新密码">
                        <mu-text-field v-model="form.password"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item prop="input" label="确认新密码">
                        <mu-text-field v-model="form.checkPassword"></mu-text-field>
                    </mu-form-item>
                </mu-form>
                <mu-flex justify-content="center" align-items="center" >
                    <mu-button full-width color="secondary" @click="updatePassword" v-loading="updatePasswordLoading">保存</mu-button>
                </mu-flex>
            </div>
        </mu-container>
    </div>
</template>

<script>
    import Appbar from "../../components/appbar";
    export default {
        name: "password",
        components: {Appbar},
        data(){
            return {
                labelPosition: 'top',
                updatePasswordLoading: false,
                form: {}
            }
        },
        methods: {
            updatePassword(){
                if (!this.form.oldPassword){
                    this.$toast.error("请输入旧密码")
                    return;
                }
                if (!this.form.password){
                    this.$toast.error("请输入新密码")
                    return;
                }
                if (this.form.checkPassowrd){
                    this.$toast.error("请确认新密码")
                    return;
                }
                if (this.form.password !== this.form.checkPassword){
                    this.$toast.error("两次密码输入不一致")
                    return;
                }
                this.updatePasswordLoading = true
                this.ser.put("api/v1/mobile/user/password", this.form).then(res => {
                    this.$toast.success("密码修改成功")
                    setTimeout(() => {
                        this.$router.go(-1);
                    }, 1000)
                }).finally(() => {
                    this.updatePasswordLoading = false
                })
            }
        }
    }
</script>

<style scoped>

</style>
<style>
    .bank-card-edit .mu-select-input{
        color: white!important;
    }
    .bank-card-edit .mu-form{
        color: white!important;
    }
    .bank-card-edit .mu-form-item{
        color: white!important;
    }
    .bank-card-edit .mu-form-item-label{
        color: gray;
    }
    .bank-card-edit .mu-input-line{
        background-color: gray;
    }
    .bank-card-edit .mu-select-action{
        color: white!important;
    }
    .mu-list.mu-list-dense{
        background-color: #424242;
    }
    .mu-text-field-input{
        color: white!important;
    }
</style>