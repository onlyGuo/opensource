<template>
    <div>
        sss
    </div>
</template>

<script>
    export default {
        name: "register",
        methods: {
        },
        mounted() {
        }
    }
</script>

<style scoped>

</style>