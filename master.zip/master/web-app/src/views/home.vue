<template>
    <div>
        <time-block :conf="conf" :init="initFun"></time-block>
        <mu-paper class="demo-paper input-box" :z-depth="2">
            <input type="number" :placeholder="'输入下注金额, ' + conf.minChip + '元起注'" v-model="money"></input>
        </mu-paper>
        <div class="action-btn">
            <mu-flex class="flex-wrapper" align-items="center">
                <mu-flex justify-content="center" fill>
                    <mu-button color="red" ripple @click="appendChip(1)" v-loading="btnLoding">下注({{conf.prize1}})</mu-button>
                </mu-flex>
                <mu-flex justify-content="center" fill>
                    <mu-button color="green" ripple @click="appendChip(2)" v-loading="btnLoding">下注({{conf.prize2}})</mu-button>
                </mu-flex>
            </mu-flex>
        </div>
        <mu-card style="margin-top: 20px; background-color: black; color: white; margin-bottom: 10px">
            <mu-card-title title="下注规则" sub-title="请仔细阅读相关规则"></mu-card-title>
            <mu-card-text style="color: white; margin-top: -30px">
                <p>1. 任何用户充值后都可进行下注, 可选择红色或绿色, 最低下注金额{{conf.minChip}}元.</p>
                <p>2. 每5分钟一轮, 用户可在开奖前{{conf.cycle - 1}}分钟进行下注, 开奖前1分钟内停止下注.</p>
                <p>3. 获奖收益计算公式为(m + {{1 - conf.rate / 100}}m) 即下注100元中奖后获得{{100 + 100 * (1 - conf.rate / 100)}}元.</p>
                <p>4. 禁止洗钱, 系统会根据相关策略实时检测. 经发现永久封号.</p>
                <p>5. 累计流水积分达10000反300元， 以此类推.</p>
            </mu-card-text>
        </mu-card>

        <div style="width: 100%; height: 320px; position: fixed; top: 60px; margin: auto;" v-if="showTraning">
            <dice :traning="traning" :showTraning="showTraning" :num1="tra.num1" :num2="tra.num2"></dice>
        </div>
    </div>
</template>

<script>
    import TimeBlock from "../components/time-block";
    import Dice from "../components/dice";
    export default {
        name: "home",
        components: {Dice, TimeBlock},
        data(){
            return {
                conf: {},
                money: '',
                btnLoding: false,
                traning: false,
                showTraning: false,
                tra: {
                    num1: 1,
                    num2: 1
                }
            }
        },
        methods: {
            appendChip(prize){
                this.btnLoding = true
                if (!this.money){
                    this.$toast.error("请输入下注金额")
                    this.btnLoding = false
                    return
                }
                this.ser.post("api/v1/mobile/prize/append", {
                    chipMoney: this.money,
                    prize: prize
                }).then(res => {
                    this.$alert("下注成功");
                }).finally(() => {
                    this.btnLoding = false
                })
            },
            initFun(num1, num2){
                this.tra.num1 = num1
                this.tra.num2 = num2
                this.traning = true
                this.showTraning = true
                setTimeout(() => {
                    this.traning = false
                    setTimeout(() => {
                        this.showTraning = false
                    }, 1000)
                }, 2000)
            }
        },
        created() {
            this.ser.get("api/v1/mobile/conf").then(res => {
                this.conf = res.data
            })
        }
    }
</script>

<style scoped>
    .input-box{
        color: white;
        background-color: black;
        height: 50px;
        margin-top: 10px;
    }
    .input-box input{
        outline: none;
        border: none;
        width: 100%;
        height: 100%;
        font-size: 20px;
        padding-left: 10px;
        padding-right: 10px;
        background-color: transparent;
        color: white;
        text-align: center;
    }
    .action-btn{
        text-align: center;
        margin-top: 20px;
    }
    .mu-card-title-container .mu-card-title{
        color: white;
    }
    .mu-card-title-container .mu-card-sub-title{
        color: white;
    }
</style>
<style>
    .action-btn .mu-button{
        width: calc(100% - 20px);
    }
</style>