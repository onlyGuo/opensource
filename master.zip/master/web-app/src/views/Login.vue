<template>
  <div class="login-bg">
    <mu-appbar style="text-align: center" :title="conf.sysName" color="primary"></mu-appbar>
    <div class="login-input-box">
      <mu-container>
        <mu-tabs :value.sync="active" color="primary" center>
          <mu-tab>登录</mu-tab>
          <mu-tab>注册</mu-tab>
        </mu-tabs>
        <div v-if="active === 0" style="color: white">
          <mu-form ref="loginForm" :model="loginForm.validateForm" class="mu-demo-form" style="color: white">
            <mu-form-item label="用户名" label-float help-text="帮助文字" prop="username" :rules="loginForm.usernameRules">
              <mu-text-field v-model="loginForm.validateForm.username" prop="username"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="密码" label-float prop="password" :rules="loginForm.passwordRules">
              <mu-text-field type="password" v-model="loginForm.validateForm.password" prop="password"></mu-text-field>
            </mu-form-item>
            <mu-form-item>
              <mu-button color="secondary" style="width: calc(100% - 20px)" round @click="doLogin" v-loading="loginLoading">登录</mu-button>
            </mu-form-item>
          </mu-form>
        </div>
        <div class="demo-text" v-if="active === 1">
          <mu-form ref="registForm" :model="registerForm.validateForm" class="mu-demo-form" style="color: white">
            <mu-form-item label="用户名" label-float help-text="帮助文字" prop="username" :rules="registerForm.usernameRules">
              <mu-text-field v-model="registerForm.validateForm.username" prop="username"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="密码" label-float prop="password" :rules="registerForm.passwordRules">
              <mu-text-field type="password" v-model="registerForm.validateForm.password" prop="password"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="确认密码" label-float prop="checkPassowrd" :rules="registerForm.checkPasswordRules">
              <mu-text-field type="password" v-model="registerForm.validateForm.checkPassowrd" prop="checkPassowrd"></mu-text-field>
            </mu-form-item>
            <mu-form-item label="图形码" label-float prop="imgCode" :rules="registerForm.valiCodeRules">
              <mu-text-field v-model="registerForm.validateForm.imgCode" prop="valiCode"
                             style="width: calc(100% - 120px)"></mu-text-field>
              <img :src="imgCodeUrl" style="height: 35px; width: 100px; margin-left: 10px; background-color: red" @click="updateImage"/>
            </mu-form-item>
            <mu-form-item label="验证码" label-float prop="valiCode" :rules="registerForm.valiCodeRules">
              <mu-text-field v-model="registerForm.validateForm.valiCode" prop="valiCode" style="width: calc(100% - 120px)"></mu-text-field>
              <mu-button color="secondary" v-loading="sendLoading" data-mu-loading-size="24" v-text="sendCodeBtnText" @click="sendPhoneCode"></mu-button>
            </mu-form-item>
            <mu-form-item label="邀请码" label-float prop="invCode" :rules="registerForm.invCodeRules">
              <mu-text-field v-model="registerForm.validateForm.invCode" prop="invCode"></mu-text-field>
            </mu-form-item>
            <mu-form-item>
              <mu-button color="secondary" style="width: calc(100% - 20px)" round @click="doRegister" v-loading="regLoading">注册</mu-button>
            </mu-form-item>
          </mu-form>
        </div>
      </mu-container>
    </div>
    <div style="text-align: center; padding-bottom: 10px">
      <button class="download-btn" @click="goToDownload">下载/更新APP</button>
    </div>

  </div>
</template>
<style>
  .mu-form-item{
    color: rgba(255,255,255,.5)!important;
  }
  .mu-text-field-input{
    color: white!important;
  }
  .mu-input{
    color: white!important;
  }
  .mu-form-item .mu-input-content{
    border-bottom: rgba(255, 255, 255, .5) solid 1px;
  }

</style>
<style scoped>
  .login-bg{
    background-image: url("../assets/login-bg.png");
    background-size: 100%;
    min-height: 100vh;
  }
  .login-input-box{
    margin-top: 190px;
    padding: 0 20px;
  }
  .download-btn{
    background-color: black;
    outline: none;
    border: white solid 1px;
    color: white;
    border-radius: 3px;
  }

</style>

<script>

export default {
  name: 'login',
  props: {
    conf: Object
  },
  data(){
    return {
      active: 0,
      loginForm: {
        usernameRules: [
          { validate: (val) => !!val, message: '必须填写用户名'},
          { validate: (val) => val.length === 11, message: '用户名必须是正确的手机号'}
        ],
        passwordRules: [
          { validate: (val) => !!val, message: '必须填写密码'},
          { validate: (val) => val.length >= 3 && val.length <= 10, message: '密码长度大于3小于10'}
        ],
        argeeRules: [{ validate: (val) => !!val, message: '必须同意用户协议'}],
        validateForm: {
          username: '',
          password: '',
        }
      },
      registerForm: {
        usernameRules: [
          { validate: (val) => !!val, message: '必须填写用户名'},
          { validate: (val) => val.length === 11, message: '用户名必须是正确的手机号'}
        ],
        passwordRules: [
          { validate: (val) => !!val, message: '必须填写密码'},
          { validate: (val) => val.length >= 3 && val.length <= 20, message: '密码长度大于3小于20'}
        ],
        checkPasswordRules: [
          { validate: (val) => !!val, message: '请确认密码'},
          { validate: (val) => val === this.$data.registerForm.validateForm.password, message: '两次密码输入不一致'}
        ],
        valiCodeRules: [
          { validate: (val) => !!val, message: '必须填写验证码'},
        ],
        invCodeRules: [
          { validate: (val) => !!val, message: '必须填写邀请码'},
        ],
        validateForm: {
          username: '',
          password: '',
          checkPassowrd: '',
          imgCode: '',
          valiCode: '',
          invCode: ''
        }
      },
      imgCodeUrl: '',
      sendLoading: false,
      regLoading: false,
      loginLoading: false,
      sendCodeBtnText: '发送验证码',
      sendCodeBtnDis: false,
      uuid: localStorage.getItem("UUID"),
    }
  },
  components: {
  },
  methods: {
    updateImage(){
      this.uuid = localStorage.getItem("UUID")
      this.imgCodeUrl = this.ser.ctx + "/api/v1/common/imageCode/" + this.uuid + "?t=" + new Date().getTime()
    },
    doRegister(){
      this.$refs.registForm.validate().then((result) => {
        if (!result){
          return
        }
        this.regLoading = true
        this.ser.post("api/v1/mobile/user/register", this.registerForm.validateForm).then(res => {
          this.$toast.success("注册成功")
          this.active = 0
        }).finally(() => {
          this.regLoading = false
        })
      });
    },
    doLogin(){
      this.$refs.loginForm.validate().then((result) => {
        if (!result){
          return
        }
        this.loginLoading = true
        this.ser.post("api/v1/mobile/user/login", this.loginForm.validateForm).then(res => {
          this.$toast.success("登录成功")
          // 保存cookie
          this.setCookie("token", res.data.token)
          localStorage.setItem("user", JSON.stringify(res.data))
          this.$router.replace({path: "/home"})
        }).finally(() => {
          this.loginLoading = false
        })
      })
    },
    sendPhoneCode(){
      if (!this.registerForm.validateForm.username){
        this.$toast.error("请输入手机号")
        return
      }
      if (!this.registerForm.validateForm.imgCode){
        this.$toast.error("请输入图片验证码")
        return
      }
      this.sendLoading = true
      this.ser.post("api/v1/common/phoneCode", {
        phone: this.registerForm.validateForm.username,
        imgCode: this.registerForm.validateForm.imgCode,
        uuid: this.uuid
      }).then(res => {
        this.$toast.success("短信发送成功")
        if (!this.timer) {
          this.count = 60;
          this.sendCodeBtnText = "再次发送(" + this.count + ")";
          this.sendCodeBtnDis = true
          this.timer = setInterval(() => {
            if (this.count > 0 && this.count <= 60) {
              this.count--;
              this.sendCodeBtnText = "再次发送(" + this.count + ")";
            } else {
              this.sendCodeBtnText = "发送验证码";
              this.sendCodeBtnDis = false
              clearInterval(this.timer);
              this.timer = null;
            }
          }, 1000)
        }
      }).catch(() => {
        this.sendLoading = false
      })
    },
    setCookie(name,value){
      let Days = 30;
      let exp = new Date();
      exp.setTime(exp.getTime() + Days*24*60*60*1000);
      document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
    },
    goToDownload(){
      this.$router.push({path: "/download"})
    }
  },
  created() {
    if(this.$route.query.invCode){
      this.registerForm.validateForm.invCode = this.$route.query.invCode
      this.active = 1
    }
    this.updateImage()
  }
}
</script>
