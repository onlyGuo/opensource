<template>
    <div class="page">
        <div class="title">
            <div class="icon">
                <img src="../assets/logo.png">
            </div>
            <div class="content">
                <div class="sys-name" v-text="conf.sysName"></div>
                <div>是赢还是输, 这是个有深度的问题...</div>
                <div>大小: 32.3 MB  版本: 1.0</div>
            </div>
        </div>
        <div class="download-btns">
            <button @click="goToDownload('/download/android.apk')">Android下载</button>
            <button @click="goToDownload('/download/ios.mobileconfig')">IOS下载</button>
        </div>
        <div class="comment">
            <div class="item">
                <img alt="喜欢" src="http://static.yingyonghui.com/resource/msite/static/images/icon_03.png">
                98%好评(82214人)
            </div>
            <div class="item">
                <img alt="评论" src="http://static.yingyonghui.com/resource/msite/static/images/icon_04.png">
                12174
            </div>
        </div>
        <div class="score">
            <div class="left">
                <div style="font-size: 20px; font-weight: bold">评分即评论</div>
                <div class="item">
                    <div class="value" style="margin-top: -10px">4.9</div>
                    <div style="text-align: center; margin-top: -15px">满分 5 分</div>
                </div>
            </div>
            <div class="right">
                <div class="line"><div style="width: 93%"></div></div>
                <div class="line"><div style="width: 30%"></div></div>
                <div class="line"><div style="width: 5%"></div></div>
                <div class="line"><div style="width: 2%"></div></div>
                <div class="line"><div style="width: 1%"></div></div>
            </div>
        </div>
        <div class="images">
            <img src="../assets/download/imgs/p1.png">
            <img src="../assets/download/imgs/p2.png">
            <img src="../assets/download/imgs/p3.png">
            <img src="../assets/download/imgs/p4.png">
            <img src="../assets/download/imgs/p5.png">
        </div>
        <div class="new-fun" style="padding: 10px">
            <div style="font-size: 20px; font-weight: bold">新功能</div>
            <p>1. 更换支付渠道, 操作更快捷, 充值无需人工审核.</p>
            <p>2. 增加当前下注人数反馈.</p>
        </div>
        <div style="padding: 10px">
            <div style="font-size: 20px; font-weight: bold">信息</div>
            <div class="info-item">
                <div class="left">大小</div>
                <div class="right">32.3 MB</div>
            </div>
            <div class="info-item">
                <div class="left">兼容性</div>
                <div class="right">Android 4.x+, IOS 10+ 版本</div>
            </div>
            <div class="info-item">
                <div class="left">语言</div>
                <div class="right">简体中文</div>
            </div>
            <div class="info-item">
                <div class="left">年龄分级</div>
                <div class="right">限18岁以上</div>
            </div>
            <div class="info-item">
                <div class="left">价格</div>
                <div class="right">免费</div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "download",
        props: {
            conf: Object
        },
        methods: {
            goToDownload(path){
                location.href = path;
            }
        },
        created() {
            this.ser.get("api/v1/mobile/conf")
        }
    }
</script>

<style scoped>
    .page{
        background-color: white;
        color: #424242;
        min-height: 100%;
    }
    .title{
        height: 100px;
        padding: 10px;
        box-shadow: rgba(0,0,0,.3) 1px 1px 10px -5px;
    }
    .title .icon{
        height: 80px;
        width: 80px;
        border-radius: 10px;
        overflow: hidden;
        display: inline-block;
        box-shadow: rgba(0,0,0,.2) 1px 1px 10px -5px;
    }
    .title .icon img{
        height: 100%;
        width: 100%;
    }
    .title .content{
        height: 80px;
        display: inline-block;
        width: calc(100% - 90px);
        margin-left: 10px;
        float: right;
    }

    .title .content .sys-name{
        font-size: 18px;
    }

    .download-btns button{
        width: 40%;
        margin: 5%;
        height: 35px;
        background-color: lightseagreen;
        border: lightseagreen;
        color: white;
        border-radius: 17px;
        outline: none;
    }
    .download-btns button:hover{
        background-color: #128983;
    }
    .comment{
        height: 25px;
        border-bottom: #e3e3e3 solid 1px;
        border-top: #e3e3e3 solid 1px;
        color: gray;
        padding-left: 10px;
        padding-right: 10px;
    }
    .comment .item{
        display: inline-block;
        width: 50%;
    }
    .comment img{
        height: 15px;
        width: 15px;
        vertical-align: middle;
    }
    .images{
        height: 300px;
        overflow-y: scroll;
        white-space:nowrap;
    }
    .images img{
        height: calc(100% - 20px);
        margin: 5px;
    }
    .score{
        padding: 10px;
    }
    .score .left{
        width: 120px;
        display: inline-block;
    }
    .score .item .value{
        font-size: 50px;
        font-weight: bold;
        text-align: center;
    }
    .score .right{
        width: 150px;
        height: 100px;
        display: inline-block;
        float: right;
    }
    .score .right .line{
        background-color: #e2e2e2; height: 10px;
        margin: 8px 0;
    }
    .score .right .line div{
        background-color: #adadad;
        height: 10px;
    }
    .info-item{
        border-bottom: #d7d7d7 solid 1px;
    }
    .info-item .left{
        color: #a7a7a7;
        display: inline-block;
    }
    .info-item .right{
        float: right;
    }
</style>