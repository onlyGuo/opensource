<template>
    <div v-loading="loading">
        <mu-tabs :value.sync="active" color="black" indicator-color="pink" full-width>
            <mu-tab>开奖记录</mu-tab>
            <mu-tab>下注记录</mu-tab>
        </mu-tabs>
        <mu-container>
            <div class="demo-text" ref="container" v-if="active === 0">
                <div style="margin: 10px">
                    <div style="height: 10px;width: 10px;background-color: red;border-radius: 5px; display: inline-block"></div>
                    <span> 大</span>
                    <div style="display: inline-block; width: 20px;"></div>
                    <div style="height: 10px;width: 10px;background-color: green;border-radius: 5px; display: inline-block"></div>
                    <span> 小</span>
                </div>
                <hr></hr>
                <table class="history-table">
                    <tr v-for="order in lastOrderList" :key="order.id">
                        <td v-for="i in order.numCondensed">
                            <div :class="{'da': order.prize === 1, 'xiao': order.prize === 2}"></div>
                        </td>
                    </tr>
                </table>
                <div class="dscp">
                    <div style="height: 100px">↑ 最近</div>
                    <div>↓ 早期</div>
                </div>
            </div>
            <div class="demo-text" v-if="active === 1">
                <mu-load-more @refresh="refreshOrderItemHis" :refreshing="itemRefreshing" :loading="itemLoading" @load="loadItems">
                    <div style="min-height: 50vh">
                        <mu-list textline="two-line">
                            <mu-list-item avatar ripple button v-for="(item, index) in orderItemHis" :key="index">
                                <mu-list-item-content>
                                    <mu-list-item-title style="color: white">第{{item.orderId}}期</mu-list-item-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">下注类型: [{{(item.prize === 1 ? '大' : '小')}}] 开奖结果: [{{item.prizeDscp}}] </mu-list-item-sub-title>
                                    <mu-list-item-sub-title style="color: #b8b8b8">
                                        下注金额: [{{item.money}}] 下注时间: {{item.createTime}}
                                    </mu-list-item-sub-title>
                                </mu-list-item-content>
                            </mu-list-item>
                        </mu-list>
                    </div>
                </mu-load-more>
            </div>
        </mu-container>

    </div>
</template>

<script>
    export default {
        name: "history2",
        data(){
            return {
                active: 0,
                refreshing: false,
                loading: false,
                orderHis: [],
                orderHisPage: 1,
                itemRefreshing: false,
                itemLoading: false,
                orderItemHisPage: 1,
                orderItemHis: [],
                lastOrderList: []
            }
        },
        methods: {

            lastOrders(){
                this.loading = true
                this.ser.get("api/v1/mobile/prize/last-orders").then(res => {
                    this.lastOrderList = res.data
                }).finally(() => {
                    this.loading = false
                })
            },

            refreshOrderItemHis(){
                this.itemRefreshing = true;
                this.orderItemHisPage = 1
                this.ser.get("api/v1/mobile/prize/orders-item?page=" + this.orderItemHisPage).then(res => {
                    this.orderItemHis = res.data
                }).finally(() => {
                    this.itemRefreshing = false;
                })
            },
            loadItems () {
                this.loading = true;
                this.ser.get("api/v1/mobile/prize/orders-item?page=" + (this.orderItemHisPage + 1)).then(res => {
                    this.orderItemHis = this.orderItemHis.concat(res.data)
                    if (res.data.length > 0){
                        this.orderItemHisPage ++;
                    }
                }).finally(() => {
                    this.itemLoading = false;
                    this.loading = false;
                })
            },
        },
        created() {
            this.lastOrders()
            this.refreshOrderItemHis()
        }
    }
</script>

<style scoped>
    .history-table{
        margin-left: 20px;
        display: inline-block;
    }
    .history-table .da{
        height: 10px;
        width: 10px;
        background-color: red;
        border-radius: 5px;
    }
    .history-table .xiao{
        height: 10px;
        width: 10px;
        background-color: green;
        border-radius: 5px;
    }
    .dscp{
        height: 130px;
        width: 50px;
        background: -webkit-linear-gradient(red, transparent); /* Safari 5.1 - 6.0 */
        background: -o-linear-gradient(red, transparent); /* Opera 11.1 - 12.0 */
        background: -moz-linear-gradient(red, transparent); /* Firefox 3.6 - 15 */
        background: linear-gradient(red, transparent); /* 标准的语法 */
        float: right;
    }
</style>