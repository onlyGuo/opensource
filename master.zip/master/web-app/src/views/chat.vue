<template>
    <div class="chat" style="overflow-y: scroll" ref="chatContent">
        <div class="chat-content">
            <div v-for="(item, index) in msgList" :key="index" class="message-item" :class="{'left': !item.me, 'right': item.me}">
                <div class="head-img">
                    <mu-row>
                        <mu-avatar size="45px">
                            <img :src="item.avatar ? item.avatar : require('../assets/logo.png')">
                        </mu-avatar>
                    </mu-row>
                </div>
                <div class="message-content">
                    <div class="nicker" v-text="item.nicker" v-if="!item.me"></div>
                    <div class="nicker-type" v-text="item.roleType === 'ADMIN'? '超管' : (item.roleType === 'REC'?'充值客服': (item.roleType === 'SER' ? '业务客服' : (item.roleType === 'MVE' ? '兑换客服' : '客服')))" v-if="item.roleType !== 'USER' && !item.me"></div>
                    <div class="content">
                        <div v-text="item.message">
                        </div>
                    </div>
                </div>
            </div>

<!--            <div class="message-item left">-->
<!--                <div class="head-img">-->
<!--                    <mu-row>-->
<!--                        <mu-avatar size="45px">-->
<!--                            <img src="../assets/logo.png">-->
<!--                        </mu-avatar>-->
<!--                    </mu-row>-->
<!--                </div>-->
<!--                <div class="message-content">-->
<!--                    <div class="nicker">奥利给</div>-->
<!--                    <div class="content">-->
<!--                        <div>-->
<!--                            卧槽, 给力啊卧槽卧槽, 给力啊卧槽卧槽, 给力啊卧槽卧槽, 给力啊卧槽卧槽, 给力啊卧槽卧槽, 给力啊卧槽-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
        </div>

        <div class="chat-edit">
            <div style="display: inline-block; height: 45px; width: 45px; overflow: hidden; background-color: rgba(255, 255, 255, .2)">
                <mu-button icon color="white" style="margin-left: -2px; margin-top: -2px">
                    <mu-icon value="image"></mu-icon>
                </mu-button>
            </div>
            <div style="display: inline-block; height: 45px; width: calc(100% - 90px); overflow: hidden">
                <input type="text" style="width: 100%" v-model="msgInputText"></input>
            </div>
            <div style="display: inline-block; height: 45px; width: 45px; overflow: hidden; background-color: rgba(255, 255, 255, .2)">
                <mu-button icon color="white" style="margin-left: -2px; margin-top: -2px" @click="sendMsg">
                    <mu-icon value="send"></mu-icon>
                </mu-button>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "chat",
        data() {
            return {
                msgList: [],
                msgInputText: ''
            }
        },
        created() {
            this.ser.get("api/v1/mobile/chat/message").then(res => {
                this.msgList = res.data
                console.log(this.msgList)
            }).finally(() => {
                this.initWebSocket()
                this.scrollToBottom()
            })
        },
        beforeDestroy () {
            this.onbeforeunload()
            clearInterval(this.timer);
        },
        methods:{
            initWebSocket () {
                if ('WebSocket' in window) {
                    let userStr = localStorage.getItem("user");
                    if (!userStr) {
                        this.$router.replace("/login")
                        return
                    }
                    if (userStr === 'undefined') {
                        this.$router.replace("/login")
                        return;
                    }
                    let user = JSON.parse(userStr);
                    this.websocket = new WebSocket(this.ser.ctx.replace("https://", "ws://")
                        .replace("http://", "ws://").replace(":90", ":89") + "/api/v1/mobile/chat/io/" + user.id)

                    // 连接错误
                    this.websocket.onerror = this.setErrorMessage

                    // 连接成功
                    this.websocket.onopen = this.setOnopenMessage

                    // 收到消息的回调
                    this.websocket.onmessage = this.setOnmessageMessage

                    // 连接关闭的回调
                    this.websocket.onclose = this.setOncloseMessage

                    // 监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
                    window.onbeforeunload = this.onbeforeunload

                    console.log('WebSocket 连接成功!');

                    // 息屏后重连
                    document.addEventListener('visibilitychange', () => {
                        if (!document.hidden) {//页面呼出
                            if (this.websocket.readyState === 2 ||
                                this.websocket.readyState === 3) {
                                this.initWebSocket()
                            }
                        }
                    })
                    this.timer = setInterval(() => {
                        this.keep()
                    }, 60000);
                } else {
                    console.log("当前设备不支持该WebSocket")
                }
            },
            setErrorMessage () {
                console.log('WebSocket连接发生错误   状态码：' + this.websocket.readyState)
                console.log('开始重连')
                setTimeout(() => {
                    this.initWebSocket()
                }, 1000)

            },
            setOnopenMessage () {
                console.log('WebSocket连接成功    状态码：' + this.websocket.readyState)
            },
            setOnmessageMessage (event) {
                console.log('服务端返回：' + event.data)
                // {"from":{"id":1,"nicker":"超管"},"msg":"234234","type":"text"}
                let msg = JSON.parse(event.data);
                if (msg.type === 'keep'){
                    return
                }
                this.msgList.push({
                    avatar: msg.from.avatar,
                    nicker: msg.from.nicker,
                    type: msg.type,
                    message: msg.msg,
                    roleType: msg.roleType
                })
                if(this.isOnBottom()){
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, 100)
                }
            },
            setOncloseMessage () {
                console.log('WebSocket连接关闭    状态码：' + this.websocket.readyState)
            },
            onbeforeunload () {
                this.closeWebSocket()
            },
            closeWebSocket () {
                this.websocket.close()
            },
            keep(){
                this.websocket.send(JSON.stringify({
                    type: 'keep'
                }))
            },
            // 滚动到最底部
            scrollToBottom () {
                this.$refs.chatContent.scrollTop = this.$refs.chatContent.scrollHeight
            },
            // 是否处于底部(误差值在100个像素点)
            isOnBottom(){
                return this.$refs.chatContent.scrollHeight - this.$refs.chatContent.scrollTop - document.getElementById("layout").offsetHeight < 100
            },
            sendMsg(){
                // 发送消息
                if(!this.msgInputText){
                    return;
                }
                let msg = {
                    type: 'text',
                    message: this.msgInputText
                }
                this.msgInputText = ''
                this.ser.post("api/v1/mobile/chat/send", msg).then(res => {
                    this.msgList.push({
                        me: true,
                        message: msg.message,
                        type: 'text'
                    })
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, 100)
                }).catch(res => {
                    alert(res.data)
                })
            }
        }
    }
</script>

<style scoped>
    .chat{
        position: absolute;
        top: 56px;
        left: 0;
        right: 0;
        bottom: 56px;
    }
    .chat-content{
        position: absolute;
        width: 100%;
        padding-bottom: 50px;
    }
    .chat-edit{
        height: 45px;
        background-color: rgba(100, 100, 100,.95);
        position: fixed;
        bottom: 56px;
        left: 0;
        right: 0;
    }
    .chat-edit input{
        background:none;
        outline:none;
        border:none;
        height: 45px;
        line-height: 45px;
        display: inline-block;
        color: white;
    }
    .message-item{
        padding: 10px;
        width: 100%;
    }
    .message-item.right{
        float: right;
    }
    .message-item.left{
        float: left;
    }
    .message-item.right .head-img{
        float: right;
    }
    .message-item .head-img{
        display: inline-block;
        height: 45px;
        width: 45px;
        vertical-align: top;
    }
    .message-item .nicker{
        color: gray;
        display: inline-block;
    }
    .message-item.right .nicker{
        text-align: right;
    }
    .message-item.left .head-img{
        margin-right: 10px;
    }
    .message-item.right .head-img{
        margin-left: 10px;
    }
    .message-item .message-content{
        display: inline-block;
        min-height: 45px;
        max-width: calc(100% - 60px);
    }
    .message-item.right .message-content{
        float: right;
    }
    .message-item .message-content .content{
        background-color: #171717;
        padding: 10px;
        margin-top: 10px;
        border-radius: 5px;
        box-shadow: black 1px 1px 10px -3px;
    }
    .message-item.right .message-content .content{
        background-color: white;
        color: black;
    }
    .nicker-type{
        display: inline-block;
        border: yellow solid 1px;
        color: yellow;
        margin-left: 4px;
        border-radius: 5px;
        font-size: 10px;
        padding-left: 3px;
        padding-right: 3px;
    }
</style>