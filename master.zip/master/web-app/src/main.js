import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Axios from 'axios';
import MuseUI from 'muse-ui';
import 'typeface-roboto'
import 'muse-ui/dist/muse-ui.css';
import Toast from 'muse-ui-toast';
import 'muse-ui-loading/dist/muse-ui-loading.css'; // load css
import Loading from 'muse-ui-loading';
import Message from 'muse-ui-message';



Vue.config.productionTip = false

Vue.use(MuseUI);
Vue.use(Toast);
Vue.use(Loading);
Vue.use(Message);

import theme from 'muse-ui/lib/theme';
theme.add('teal', {
  primary: '#000000',
  secondary: '#ff4081',
  success: '#4caf50',
  warning: '#ffeb3b',
}, 'dark');

theme.use('teal');



// Axios.defaults.baseURL = "http://localhost:8891"
// Axios.defaults.baseURL = "http://192.168.3.11:8891"
// Axios.defaults.baseURL = "http://192.168.3.11:8891"
// Axios.defaults.baseURL = "http://156.96.148.124:89"
// Axios.defaults.baseURL = "http://" + window.location.host
Axios.defaults.baseURL = "http://juzi.shengtaiyuan.xyz:90/"
Axios.defaults.timeout = 10000
Axios.defaults.headers.get['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.put['Content-Type'] = 'application/json;charset=UTF-8'
Axios.defaults.headers.delete['Content-Type'] = 'application/json;charset=UTF-8'
Axios.interceptors.request.use(
    config => {
      // 允许携带cookie
      config.withCredentials = true
      return config
    },
    error => {
      return Promise.error(error)
    }
)

// 响应拦截
// 响应拦截器
Axios.interceptors.response.use(
    response => {
      if (response.status === 200) {
        return Promise.resolve(response)
      } else {
        return Promise.reject(response)
      }
    },
    // 服务器状态码不是200的情况
    error => {
      console.log(error)
      if (error.response.status) {
        if (error.response.status == 401) {
          router.replace({
            path: '/login'
          })
        } else if (error.response.status == 400) {
          if (error.response.data.message == '未抢到') {
            return Promise.reject(error.response)
          }
          if (error.response.data.message.indexOf("当前时间段不能") !== -1) {
            return Promise.reject(error.response)
          }
          Toast.error(error.response.data.message)
        } else {
            Toast.error("网络错误，请稍后再试")
        }
        return Promise.reject(error.response)
      }
    }
)
Vue.prototype.ser = Axios
Vue.prototype.ser.ctx = Axios.defaults.baseURL

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
