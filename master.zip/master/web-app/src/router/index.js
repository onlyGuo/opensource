import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '../views/layout'

Vue.use(VueRouter)

const routes = [
    {
        path: '/login',
        name: 'login',
        component: () => import('../views/Login')
    },
    {
        path: '/',
        component: Layout,
        children: [
            {
                path: '', redirect: 'home'
            },
            {
                path: 'home',
                component: () => import('../views/home')
            },
            {
                path: 'chat',
                component: () => import('../views/chat')
            },
            {
                path: 'history',
                component: () => import('../views/history3')
            },
            {
                path: 'setting',
                component: () => import('../views/setting/index')
            },
        ],
    },
    {
        path: '/setting/info',
        component: () => import('../views/setting/info')
    },
    {
        path: '/setting/bank',
        component: () => import('../views/setting/bank')
    },
    {
        path: '/setting/assets',
        component: () => import('../views/setting/assets')
    },
    {
        path: '/setting/password',
        component: () => import('../views/setting/password')
    },
    {
        path: '/setting/recharge',
        component: () => import('../views/setting/recharge')
    },
    {
        path: '/setting/withdrawal',
        component: () => import('../views/setting/withdrawal')
    },
    {
        path: '/setting/idcard',
        component: () => import('../views/setting/idcard')
    },
    {
        path: '/download',
        component: () => import('../views/download')
    },
]

const router = new VueRouter({
    mode: 'hash',
    base: process.env.BASE_URL,
    routes
})

export default router
